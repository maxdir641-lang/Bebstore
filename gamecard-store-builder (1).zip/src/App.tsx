import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Language, GameType, RechargePackage, RechargeOrder, translations } from './types';
import { Gamepad2, CreditCard, Clock, CheckCircle2, History, Shield, Zap, Sparkles, TrendingUp, Users, Lock, X } from 'lucide-react';
import { freefirePackages, pubgPackages, googlePlayPackages } from './data';
import LanguageToggle from './components/LanguageToggle';
import FreeFireForm from './components/FreeFireForm';
import PubgForm from './components/PubgForm';
import GooglePlayForm from './components/GooglePlayForm';
import CheckoutModal from './components/CheckoutModal';
import ReceiptScreen from './components/ReceiptScreen';
import OrderHistory from './components/OrderHistory';
import SupportChat from './components/SupportChat';
import AdminPanel from './components/AdminPanel';

export default function App() {
  const [lang, setLang] = useState<Language>('ar'); // Default to Arabic as gaming card portals are extremely popular there, can toggle to EN easily
  const [activeTab, setActiveTab] = useState<GameType>('freefire');
  const [viewHistory, setViewHistory] = useState(false);
  const [orders, setOrders] = useState<RechargeOrder[]>([]);

  // Dynamic store packages loaded from localStorage (fallback to static data)
  const [packages, setPackages] = useState<RechargePackage[]>(() => {
    const saved = localStorage.getItem('gamer_recharge_packages');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [...freefirePackages, ...pubgPackages, ...googlePlayPackages];
  });

  // Admin Portal state
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAdminPromptOpen, setIsAdminPromptOpen] = useState(false);
  const [adminPasscode, setAdminPasscode] = useState('');
  const [adminError, setAdminError] = useState('');

  const updatePackagesState = (updated: RechargePackage[]) => {
    setPackages(updated);
    localStorage.setItem('gamer_recharge_packages', JSON.stringify(updated));
  };

  const handleAdminLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPasscode === 'admin123') {
      setIsAdminOpen(true);
      setIsAdminPromptOpen(false);
      setAdminPasscode('');
      setAdminError('');
    } else {
      setAdminError(lang === 'en' ? 'Incorrect passcode. Try "admin123"' : 'رمز المرور خاطئ. جرب "admin123"');
    }
  };

  // Checkout States
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [checkoutTarget, setCheckoutTarget] = useState('');
  const [checkoutNickname, setCheckoutNickname] = useState('');
  const [checkoutRegion, setCheckoutRegion] = useState('');
  const [checkoutPack, setCheckoutPack] = useState<RechargePackage | null>(null);

  // Active Receipt State (for immediate success)
  const [activeReceipt, setActiveReceipt] = useState<RechargeOrder | null>(null);

  // Real-Time Activity Ticker (simulating live successful orders worldwide)
  const [liveTicker, setLiveTicker] = useState<Array<{ name: string; game: string; value: string; time: string }>>([]);

  // Load orders from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('gamer_recharge_orders');
    if (saved) {
      try {
        setOrders(JSON.parse(saved));
      } catch (e) {
        console.error(e);
      }
    }

    // Populate initial live activity ticker
    const initialTicker = [
      { name: 'FF_Viper99', game: 'freefire', value: '520 💎', time: '1s ago' },
      { name: 'Alpha_Warrior_PUBG', game: 'pubg', value: '660 UC 🪙', time: '4s ago' },
      { name: 'user_4821**', game: 'googleplay', value: '$25 Card 💳', time: '12s ago' },
      { name: 'EliteKnightFF', game: 'freefire', value: '2180 💎', time: '18s ago' },
      { name: 'DesertFox_PUBG', game: 'pubg', value: '1800 UC 🪙', time: '29s ago' }
    ];
    setLiveTicker(initialTicker);

    // Dynamic rotation of live activities for deep authenticity
    const interval = setInterval(() => {
      const names = ['SniperBoss', 'MajorStrike', 'Phoenix_FF', 'ZeusPUBG', 'user_9812**', 'GhostRaptor', 'ViperX', 'ff_Elite'];
      const games = ['freefire', 'pubg', 'googleplay'];
      const randomName = names[Math.floor(Math.random() * names.length)];
      const randomGame = games[Math.floor(Math.random() * games.length)];
      
      let val = '';
      if (randomGame === 'freefire') {
        const FFAmounts = ['100 💎', '310 💎', '520 💎', '1060 💎'];
        val = FFAmounts[Math.floor(Math.random() * FFAmounts.length)];
      } else if (randomGame === 'pubg') {
        const PUBGAmounts = ['60 UC 🪙', '325 UC 🪙', '660 UC 🪙'];
        val = PUBGAmounts[Math.floor(Math.random() * PUBGAmounts.length)];
      } else {
        const GPAmounts = ['$10 Card 💳', '$25 Card 💳', '$50 Card 💳'];
        val = GPAmounts[Math.floor(Math.random() * GPAmounts.length)];
      }

      setLiveTicker((prev) => [
        { name: randomName, game: randomGame, value: val, time: 'Just now' },
        ...prev.slice(0, 4).map((item) => ({
          ...item,
          time: item.time === 'Just now' ? '3s ago' : item.time.includes('s') ? `${parseInt(item.time) + 3}s ago` : '1m ago'
        }))
      ]);
    }, 4500);

    return () => clearInterval(interval);
  }, []);

  const t = translations[lang];

  const handleInitiateRecharge = (
    target: string,
    pack: RechargePackage,
    nickname: string,
    region: string
  ) => {
    setCheckoutTarget(target);
    setCheckoutPack(pack);
    setCheckoutNickname(nickname);
    setCheckoutRegion(region);
    setIsCheckoutOpen(true);
  };

  const handlePaymentSuccess = (newOrder: RechargeOrder) => {
    const updatedOrders = [newOrder, ...orders];
    setOrders(updatedOrders);
    localStorage.setItem('gamer_recharge_orders', JSON.stringify(updatedOrders));
    
    setIsCheckoutOpen(false);
    setActiveReceipt(newOrder);
  };

  const isRTL = lang === 'ar';

  return (
    <div
      dir={isRTL ? 'rtl' : 'ltr'}
      className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950 pb-12"
    >
      {/* Dynamic Ambient Background Glows */}
      <div className="absolute top-0 inset-x-0 h-[500px] overflow-hidden pointer-events-none -z-10">
        <div className="absolute top-[-10%] left-[20%] w-[350px] h-[350px] rounded-full bg-emerald-500/10 blur-[120px] animate-pulse" />
        <div className="absolute top-[-5%] right-[25%] w-[400px] h-[400px] rounded-full bg-teal-500/10 blur-[130px]" />
      </div>

      {/* Main Top Navigation Bar */}
      <nav className="border-b border-slate-900/80 bg-slate-950/80 backdrop-blur-md sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-400 text-slate-950 shadow-lg shadow-emerald-500/20">
              <Gamepad2 className="w-6 h-6" />
            </div>
            <div>
              <span className="font-display font-black text-xl tracking-wider uppercase bg-gradient-to-r from-white via-slate-100 to-emerald-400 bg-clip-text text-transparent">
                {t.appName}
              </span>
              <span className="text-[10px] text-emerald-400 font-bold block leading-none uppercase tracking-widest font-display mt-0.5">
                {lang === 'en' ? 'Direct Gateway' : 'بوابة الشحن المعتمدة'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* Bilingual Switcher */}
            <LanguageToggle currentLanguage={lang} onLanguageChange={setLang} />

            {/* View History Pill */}
            {!viewHistory && (
              <button
                id="btn-nav-history"
                onClick={() => setViewHistory(true)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-full border border-slate-800 bg-slate-900/40 text-xs font-semibold text-slate-300 hover:text-slate-100 hover:border-slate-700 transition-all cursor-pointer"
              >
                <History className="w-4 h-4 text-emerald-400" />
                <span>{t.viewHistory}</span>
                {orders.length > 0 && (
                  <span className="w-4 h-4 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-black flex items-center justify-center">
                    {orders.length}
                  </span>
                )}
              </button>
            )}

            {viewHistory && (
              <button
                id="btn-nav-recharge"
                onClick={() => setViewHistory(false)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-slate-900 border border-slate-800 text-xs font-bold text-slate-200 hover:bg-slate-850 transition-all cursor-pointer"
              >
                <span>{t.home}</span>
              </button>
            )}
          </div>
        </div>
      </nav>

      {/* Main Container Deck */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 mt-8 flex-1 w-full space-y-8">
        
        {/* Dynamic Billing Status Banner */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-4 bg-slate-900/40 border border-slate-850 rounded-2xl gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping shrink-0" />
            <span className="font-semibold text-slate-200">
              {lang === 'en' ? 'Server API Status: SECURE & OPERATIONAL' : 'حالة سيرفر الاتصال: آمن ويعمل بكفاءة'}
            </span>
          </div>
          <div className="flex items-center gap-4 flex-wrap">
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              <span>{lang === 'en' ? 'Avg. Delivery: 4.8 seconds' : 'متوسط وقت التسليم: 4.8 ثانية'}</span>
            </span>
            <span className="flex items-center gap-1">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>{lang === 'en' ? 'Official Partner Authorization' : 'اعتماد رسمي مباشر 100%'}</span>
            </span>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {activeReceipt ? (
            /* Active Receipt Overlay View (When purchase succeeds) */
            <motion.div
              key="active-receipt"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="py-6"
            >
              <div className="text-center mb-6">
                <button
                  id="btn-receipt-back"
                  onClick={() => setActiveReceipt(null)}
                  className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs font-semibold text-slate-400 hover:text-slate-100 transition-colors"
                >
                  {lang === 'en' ? '← Back to Recharge' : '← العودة لمتجر الشحن'}
                </button>
              </div>
              <ReceiptScreen
                lang={lang}
                t={t}
                order={activeReceipt}
                onClose={() => setActiveReceipt(null)}
              />
            </motion.div>
          ) : viewHistory ? (
            /* Historical Orders View */
            <motion.div
              key="orders-history"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 15 }}
            >
              <OrderHistory
                lang={lang}
                t={t}
                orders={orders}
                onBackToStore={() => setViewHistory(false)}
              />
            </motion.div>
          ) : (
            /* Master Recharge Form Dashboard */
            <motion.div
              key="storefront"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-8"
            >
              {/* Left & Middle Column (2/3 width on Desktop): Game Selector and Form */}
              <div className="lg:col-span-2 space-y-6">
                
                {/* Hero Headings */}
                <div className="space-y-2">
                  <h1 className="text-3xl sm:text-4xl font-black font-display tracking-tight text-white leading-tight">
                    {t.subtitle}
                  </h1>
                  <p className="text-sm text-slate-400 leading-relaxed max-w-xl">
                    {t.tagline}
                  </p>
                </div>

                {/* Unified Tab Selector for Games */}
                <div className="bg-slate-900/60 border border-slate-800 p-2 rounded-2xl grid grid-cols-3 gap-2">
                  <button
                    id="tab-freefire"
                    onClick={() => setActiveTab('freefire')}
                    className={`relative py-3.5 px-3 rounded-xl flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      activeTab === 'freefire' ? 'bg-orange-500 text-slate-950 font-extrabold shadow-md' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <span className="text-xl">🔥</span>
                    <span className="text-xs font-semibold tracking-wider font-display">
                      {lang === 'en' ? 'Free Fire' : 'فري فاير'}
                    </span>
                  </button>
                  <button
                    id="tab-pubg"
                    onClick={() => setActiveTab('pubg')}
                    className={`relative py-3.5 px-3 rounded-xl flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      activeTab === 'pubg' ? 'bg-yellow-500 text-slate-950 font-extrabold shadow-md' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <span className="text-xl">🪂</span>
                    <span className="text-xs font-semibold tracking-wider font-display">
                      {lang === 'en' ? 'PUBG Mobile' : 'ببجي موبايل'}
                    </span>
                  </button>
                  <button
                    id="tab-googleplay"
                    onClick={() => setActiveTab('googleplay')}
                    className={`relative py-3.5 px-3 rounded-xl flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      activeTab === 'googleplay' ? 'bg-emerald-500 text-slate-950 font-extrabold shadow-md' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <span className="text-xl">💳</span>
                    <span className="text-xs font-semibold tracking-wider font-display">
                      {lang === 'en' ? 'Google Play' : 'جوجل بلاي'}
                    </span>
                  </button>
                </div>

                {/* Tab Description Context banner */}
                <div className="bg-slate-950 border border-slate-900 p-4 rounded-xl flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-850">
                    {activeTab === 'freefire' && <span className="text-lg">💎</span>}
                    {activeTab === 'pubg' && <span className="text-lg">🪙</span>}
                    {activeTab === 'googleplay' && <span className="text-lg">💳</span>}
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-200">
                      {activeTab === 'freefire' ? t.freefireTitle : activeTab === 'pubg' ? t.pubgTitle : t.googlePlayTitle}
                    </h3>
                    <p className="text-[11px] text-slate-500 mt-0.5 leading-normal">
                      {activeTab === 'freefire' ? t.freefireDesc : activeTab === 'pubg' ? t.pubgDesc : t.googlePlayDesc}
                    </p>
                  </div>
                </div>

                {/* Selected Form Component rendering */}
                <div className="p-6 bg-slate-900/30 border border-slate-850 rounded-3xl shadow-xl">
                  {activeTab === 'freefire' && (
                    <FreeFireForm
                      lang={lang}
                      t={t}
                      onInitiateRecharge={handleInitiateRecharge}
                      packages={packages.filter(p => p.game === 'freefire')}
                    />
                  )}
                  {activeTab === 'pubg' && (
                    <PubgForm
                      lang={lang}
                      t={t}
                      onInitiateRecharge={handleInitiateRecharge}
                      packages={packages.filter(p => p.game === 'pubg')}
                    />
                  )}
                  {activeTab === 'googleplay' && (
                    <GooglePlayForm
                      lang={lang}
                      t={t}
                      onInitiateRecharge={handleInitiateRecharge}
                      packages={packages.filter(p => p.game === 'googleplay')}
                    />
                  )}
                </div>
              </div>

              {/* Right Column (1/3 width on Desktop): Live Activity Ticker & FAQ Summary */}
              <div className="space-y-6">
                
                {/* Visual Trust Badge Widget */}
                <div className="bg-gradient-to-br from-emerald-950/20 to-teal-950/10 border border-emerald-900/30 p-5 rounded-3xl space-y-4">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl">
                      <Zap className="w-5 h-5 text-emerald-400 animate-pulse" />
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                        {lang === 'en' ? 'GamerCharge Guarantee' : 'ضمان غيمر تشارج المعتمد'}
                      </h3>
                      <span className="text-[10px] text-emerald-400 font-bold block">100% Secure, Safe API</span>
                    </div>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {lang === 'en'
                      ? 'Recharge orders link directly with the publishers servers using authorized system protocols. Safe from game bans or billing locks.'
                      : 'عمليات الشحن تتم مباشرة بالتنسيق مع سيرفرات الألعاب الرسمية عبر بروتوكولات معتمدة. آمنة تماماً ومضمونة ضد الحظر أو الإيقاف.'}
                  </p>
                  
                  {/* Grid stats */}
                  <div className="grid grid-cols-2 gap-3.5 pt-2 border-t border-emerald-950/60">
                    <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-900 text-center">
                      <div className="flex items-center justify-center gap-1 text-slate-200">
                        <Users className="w-3.5 h-3.5 text-slate-500" />
                        <span className="font-mono font-black text-sm">1.8M+</span>
                      </div>
                      <span className="text-[10px] text-slate-500 block mt-0.5">
                        {lang === 'en' ? 'Active Players' : 'لاعب نشط'}
                      </span>
                    </div>
                    <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-900 text-center">
                      <div className="flex items-center justify-center gap-1 text-slate-200">
                        <TrendingUp className="w-3.5 h-3.5 text-slate-500" />
                        <span className="font-mono font-black text-sm">99.9%</span>
                      </div>
                      <span className="text-[10px] text-slate-500 block mt-0.5">
                        {lang === 'en' ? 'Success Rate' : 'معدل نجاح فوري'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Live Order Activity Ticker (Looks incredibly live and active) */}
                <div className="bg-slate-900/40 border border-slate-850 rounded-3xl p-5 space-y-4 shadow-xl">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-300 uppercase tracking-widest flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      {lang === 'en' ? 'Live Top-Up Log' : 'عمليات شحن فوري مباشرة'}
                    </span>
                    <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping" />
                  </div>

                  <div className="space-y-2.5 max-h-[280px] overflow-y-auto no-scrollbar">
                    <AnimatePresence>
                      {liveTicker.map((ticker, idx) => (
                        <motion.div
                          key={`${ticker.name}-${idx}`}
                          initial={{ opacity: 0, x: isRTL ? 15 : -15 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, scale: 0.9 }}
                          className="flex items-center justify-between p-3 bg-slate-950 border border-slate-900/60 rounded-xl"
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-xs">
                              {ticker.game === 'freefire' ? '💎' : ticker.game === 'pubg' ? '🪙' : '💳'}
                            </span>
                            <div className="text-left">
                              <span className="font-mono font-bold text-slate-300 text-[11px] block">
                                {ticker.name}
                              </span>
                              <span className="text-[9px] text-slate-500 block">
                                {ticker.game === 'freefire' ? 'Free Fire' : ticker.game === 'pubg' ? 'PUBG' : 'Google Play'}
                              </span>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="text-[10px] text-emerald-400 font-extrabold block">
                              +{ticker.value}
                            </span>
                            <span className="text-[8px] text-slate-500 block">
                              {ticker.time}
                            </span>
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Floating Support AI Chatbot */}
      <SupportChat lang={lang} t={t} />

      {/* Secure Checkout Dialog Modal */}
      {checkoutPack && (
        <CheckoutModal
          lang={lang}
          t={t}
          isOpen={isCheckoutOpen}
          onClose={() => setIsCheckoutOpen(false)}
          target={checkoutTarget}
          gameNickname={checkoutNickname}
          region={checkoutRegion}
          selectedPack={checkoutPack}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

      {/* Footer with Admin Gateway */}
      <footer className="max-w-6xl mx-auto px-4 sm:px-6 mt-16 pt-8 border-t border-slate-900 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-500">
        <div>
          © 2026 GamerCard. All Rights Reserved. Authorized Game Recharging Gateway.
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={() => setIsAdminPromptOpen(true)}
            className="flex items-center gap-1.5 hover:text-rose-400 transition-colors bg-slate-900/40 hover:bg-slate-900 border border-slate-850 px-3 py-1.5 rounded-full cursor-pointer text-[11px]"
          >
            <Lock className="w-3 h-3 text-rose-500" />
            <span>{lang === 'en' ? 'Merchant Control Panel' : 'بوابة التاجر والمشرف'}</span>
          </button>
        </div>
      </footer>

      {/* Admin Passcode Entry Modal */}
      <AnimatePresence>
        {isAdminPromptOpen && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="bg-slate-900 border border-slate-800 p-6 rounded-2xl max-w-sm w-full space-y-4 shadow-2xl relative"
            >
              <button 
                onClick={() => {
                  setIsAdminPromptOpen(false);
                  setAdminPasscode('');
                  setAdminError('');
                }}
                className="absolute top-4 right-4 text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="flex flex-col items-center text-center space-y-2">
                <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded-2xl">
                  <Lock className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-white">
                  {lang === 'en' ? 'Secure Admin Entrance' : 'دخول المشرف المعتمد'}
                </h3>
                <p className="text-xs text-slate-400">
                  {lang === 'en' 
                    ? 'Enter merchant code to access live logs, modify active price points, and configure live store settings.' 
                    : 'الرجاء إدخال رمز التحقق للوصول إلى تفاصيل الأرباح، تعديل أسعار الباقات وإدارة المتجر.'}
                </p>
              </div>

              <form onSubmit={handleAdminLoginSubmit} className="space-y-3">
                <input
                  type="password"
                  placeholder={lang === 'en' ? 'Enter Passcode (admin123)' : 'أدخل رمز المرور (admin123)'}
                  value={adminPasscode}
                  onChange={(e) => setAdminPasscode(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-center text-sm font-mono tracking-widest text-white focus:outline-none focus:ring-2 focus:ring-rose-500/40 focus:border-rose-500/60 transition-all placeholder:text-slate-600 placeholder:tracking-normal"
                />

                {adminError && (
                  <p className="text-center text-[11px] text-rose-400 font-medium">
                    ⚠️ {adminError}
                  </p>
                )}

                <button
                  type="submit"
                  className="w-full py-3 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl tracking-wide transition-all shadow-lg hover:shadow-rose-500/15 cursor-pointer"
                >
                  {lang === 'en' ? 'Verify Credentials' : 'تأكيد الرمز والدخول'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Full Screen Live Admin Overlay Dashboard */}
      {isAdminOpen && (
        <AdminPanel
          lang={lang}
          onClose={() => setIsAdminOpen(false)}
          packages={packages}
          orders={orders}
          onUpdatePackages={updatePackagesState}
          onUpdateOrders={(updatedOrders) => {
            setOrders(updatedOrders);
            localStorage.setItem('gamer_recharge_orders', JSON.stringify(updatedOrders));
          }}
        />
      )}
    </div>
  );
}
