import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Language, RechargeOrder } from '../types';
import { Search, Eye, Sparkles, Receipt, Calendar, ArrowRight, Gamepad2, CreditCard } from 'lucide-react';
import ReceiptScreen from './ReceiptScreen';

interface OrderHistoryProps {
  lang: Language;
  t: any;
  orders: RechargeOrder[];
  onBackToStore: () => void;
}

export default function OrderHistory({ lang, t, orders, onBackToStore }: OrderHistoryProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedHistoryOrder, setSelectedHistoryOrder] = useState<RechargeOrder | null>(null);

  const filteredOrders = orders.filter((order) => {
    const q = searchQuery.toLowerCase();
    return (
      order.id.toLowerCase().includes(q) ||
      order.playerTarget.toLowerCase().includes(q) ||
      order.packageName.toLowerCase().includes(q) ||
      (order.gameNickname && order.gameNickname.toLowerCase().includes(q))
    );
  });

  const isRTL = lang === 'ar';

  return (
    <div className="space-y-6">
      {/* Back to store navigation bar */}
      <div className="flex items-center justify-between">
        <button
          id="btn-back-to-topup"
          onClick={onBackToStore}
          className="flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-slate-100 transition-colors"
        >
          <ArrowRight className={`w-4 h-4 ${isRTL ? '' : 'rotate-180'}`} />
          <span>{lang === 'en' ? 'Back to Charging Portal' : 'العودة لبوابة الشحن'}</span>
        </button>
        <span className="text-xs text-slate-500 font-mono">
          {orders.length} {lang === 'en' ? 'total orders recorded' : 'إجمالي العمليات المسجلة'}
        </span>
      </div>

      <AnimatePresence mode="wait">
        {selectedHistoryOrder ? (
          /* Drill down to view Receipt Screen */
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-400 flex items-center gap-1.5">
                <Receipt className="w-4 h-4" />
                {lang === 'en' ? 'Viewing Saved Invoice' : 'عرض الفاتورة المحفوظة'}
              </h3>
              <button
                id="btn-close-invoice-drilldown"
                onClick={() => setSelectedHistoryOrder(null)}
                className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg"
              >
                {lang === 'en' ? 'Back to History' : 'العودة للسجل'}
              </button>
            </div>
            <ReceiptScreen
              lang={lang}
              t={t}
              order={selectedHistoryOrder}
              onClose={() => setSelectedHistoryOrder(null)}
            />
          </div>
        ) : (
          /* Main History List */
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="space-y-4"
          >
            {/* Header Description */}
            <div className="bg-gradient-to-r from-slate-950 to-slate-900/60 border border-slate-850 p-6 rounded-3xl relative overflow-hidden">
              <div className="absolute right-4 bottom-0 text-slate-800/10 pointer-events-none">
                <Receipt className="w-32 h-32" />
              </div>
              <h2 className="text-xl font-bold font-display text-slate-100 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-emerald-400" />
                {t.orderHistoryTitle}
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                {lang === 'en'
                  ? 'Access your purchase history, fetch direct top-up ticket status, or download digital codes anytime.'
                  : 'تتبع عمليات الشحن السابقة الخاصة بك، وتحقق من وصول الرصيد، أو احصل على أكواد بطاقاتك الرقمية في أي وقت.'}
              </p>
            </div>

            {/* Search filter input */}
            <div className="relative">
              <input
                id="search-orders"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t.searchHistoryPlaceholder}
                className={`w-full bg-slate-950 border border-slate-800/80 text-slate-200 text-xs rounded-2xl py-3.5 ${
                  isRTL ? 'pr-11 pl-4' : 'pl-11 pr-4'
                } placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-emerald-500/40 focus:border-emerald-500/40 transition-all ${
                  isRTL ? 'text-right' : 'text-left'
                }`}
              />
              <div className={`absolute top-1/2 -translate-y-1/2 ${isRTL ? 'right-4' : 'left-4'} text-slate-500`}>
                <Search className="w-4 h-4" />
              </div>
            </div>

            {/* History Table / Cards */}
            {filteredOrders.length === 0 ? (
              <div className="text-center py-16 border border-dashed border-slate-800 rounded-3xl space-y-3 bg-slate-950/20">
                <div className="mx-auto w-12 h-12 rounded-full bg-slate-900 flex items-center justify-center text-slate-600 border border-slate-850">
                  <Receipt className="w-5 h-5" />
                </div>
                <p className="text-xs text-slate-500">{t.noOrders}</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredOrders.map((order) => {
                  // Style colors based on game type
                  const borderClass =
                    order.game === 'freefire'
                      ? 'border-orange-500/30 hover:border-orange-500/60 bg-gradient-to-r from-slate-950 to-orange-950/5'
                      : order.game === 'pubg'
                      ? 'border-yellow-500/30 hover:border-yellow-500/60 bg-gradient-to-r from-slate-950 to-yellow-950/5'
                      : 'border-emerald-500/30 hover:border-emerald-500/60 bg-gradient-to-r from-slate-950 to-emerald-950/5';

                  const badgeBg =
                    order.game === 'freefire'
                      ? 'bg-orange-500/10 text-orange-400 border-orange-500/20'
                      : order.game === 'pubg'
                      ? 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
                      : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';

                  return (
                    <div
                      key={order.id}
                      className={`p-4 rounded-2xl border transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${borderClass}`}
                    >
                      {/* Left Block: Game Type & Details */}
                      <div className="flex items-start gap-3.5">
                        <div className={`p-3 rounded-xl border shrink-0 ${badgeBg}`}>
                          {order.game === 'googleplay' ? (
                            <CreditCard className="w-5 h-5" />
                          ) : (
                            <Gamepad2 className="w-5 h-5" />
                          )}
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-200 text-sm">
                              {order.packageName}
                            </span>
                            <span className="text-[10px] text-slate-500 font-mono">
                              {order.id}
                            </span>
                          </div>
                          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-400">
                            <span className="font-mono bg-slate-900 border border-slate-800 px-1.5 py-0.5 rounded text-[10px] text-slate-300">
                              {order.playerTarget}
                            </span>
                            {order.gameNickname && order.gameNickname !== 'Digital Card Code Customer' && (
                              <span className="text-emerald-400 font-medium">
                                • {order.gameNickname}
                              </span>
                            )}
                            <span className="text-slate-500 flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {order.timestamp}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Right Block: Price, Status & Actions */}
                      <div className="flex items-center justify-between md:justify-end gap-6 border-t md:border-t-0 border-slate-900 pt-3 md:pt-0">
                        <div className="text-left md:text-right">
                          <span className="text-[10px] text-slate-500 block uppercase tracking-wider">{t.priceLabel}</span>
                          <span className="font-extrabold text-amber-400 text-base">
                            {t.currencySymbol}
                            {order.packagePrice.toFixed(2)}
                          </span>
                        </div>

                        <div className="flex items-center gap-3">
                          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                            {t.statusCompleted}
                          </span>
                          <button
                            id={`btn-view-invoice-${order.id}`}
                            onClick={() => setSelectedHistoryOrder(order)}
                            className="p-2 bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700 transition-colors rounded-xl flex items-center gap-1.5 text-xs"
                          >
                            <Eye className="w-4 h-4" />
                            <span className="hidden sm:inline">{lang === 'en' ? 'Invoice' : 'الفاتورة'}</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
