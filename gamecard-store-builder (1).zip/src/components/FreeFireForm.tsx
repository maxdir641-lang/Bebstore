import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Language, RechargePackage } from '../types';
import { freefirePackages, regions, getNicknameForId } from '../data';
import { CheckCircle2, User, HelpCircle, ShieldCheck } from 'lucide-react';

interface FreeFireFormProps {
  lang: Language;
  t: any;
  onInitiateRecharge: (target: string, pack: RechargePackage, nickname: string, region: string) => void;
  packages?: RechargePackage[];
}

export default function FreeFireForm({ lang, t, onInitiateRecharge, packages }: FreeFireFormProps) {
  const [playerId, setPlayerId] = useState('');
  const [region, setRegion] = useState('');
  const [selectedPack, setSelectedPack] = useState<RechargePackage | null>(null);
  
  // Nickname Verification State
  const [isVerifying, setIsVerifying] = useState(false);
  const [verifiedName, setVerifiedName] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  // Automatically check nickname when 8+ digit ID is entered
  useEffect(() => {
    const numericId = playerId.replace(/\D/g, '');
    if (numericId.length >= 8 && numericId.length <= 14) {
      setIsVerifying(true);
      setErrorMsg('');
      const timer = setTimeout(() => {
        const nick = getNicknameForId('freefire', numericId);
        setVerifiedName(nick);
        setIsVerifying(false);
      }, 1000);
      return () => clearTimeout(timer);
    } else {
      setVerifiedName(null);
      if (playerId.length > 0 && !/^\d+$/.test(playerId)) {
        setErrorMsg(lang === 'en' ? 'ID must contain numbers only' : 'يجب أن يحتوي المعرف على أرقام فقط');
      } else {
        setErrorMsg('');
      }
    }
  }, [playerId, lang]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!playerId || !/^\d+$/.test(playerId)) {
      setErrorMsg(lang === 'en' ? 'Please enter a valid numeric ID' : 'يرجى إدخال معرف رقمي صحيح');
      return;
    }
    if (playerId.length < 8) {
      setErrorMsg(lang === 'en' ? 'Player ID must be at least 8 digits' : 'يجب أن يكون معرف اللاعب 8 أرقام على الأقل');
      return;
    }
    if (!region) {
      setErrorMsg(lang === 'en' ? 'Please select your game region' : 'يرجى اختيار سيرفر اللعبة الخاص بك');
      return;
    }
    if (!selectedPack) {
      setErrorMsg(lang === 'en' ? 'Please select a diamond package' : 'يرجى اختيار باقة الجواهر');
      return;
    }

    const nickname = verifiedName || getNicknameForId('freefire', playerId);
    onInitiateRecharge(playerId, selectedPack, nickname, region);
  };

  const isRTL = lang === 'ar';

  return (
    <form id="freefire-form" onSubmit={handleSubmit} className="space-y-6">
      {/* Step 1: Account Information */}
      <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 shadow-xl">
        <div className="flex items-center gap-2 text-orange-500 font-display font-semibold text-sm tracking-wider uppercase">
          <span className="flex items-center justify-center w-5 h-5 rounded-full bg-orange-500/10 text-xs border border-orange-500/20">1</span>
          {lang === 'en' ? 'Account Credentials' : 'بيانات الحساب ومُعرّف اللاعب'}
        </div>

        <div className="space-y-2">
          <label className="block text-xs font-semibold text-slate-400">
            {t.playerIDLabel} <span className="text-orange-500">*</span>
          </label>
          <div className="relative">
            <input
              id="ff-player-id"
              type="text"
              value={playerId}
              onChange={(e) => setPlayerId(e.target.value.replace(/\D/g, ''))}
              placeholder={t.playerIDPlaceholder}
              maxLength={14}
              className={`w-full bg-slate-950 border text-sm rounded-xl py-3 px-4 text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-orange-500/40 transition-all ${
                errorMsg ? 'border-rose-500/50' : 'border-slate-800 focus:border-orange-500/60'
              } ${isRTL ? 'text-right' : 'text-left'}`}
            />
            <div className={`absolute top-1/2 -translate-y-1/2 ${isRTL ? 'left-3' : 'right-3'} flex items-center gap-2`}>
              {isVerifying && (
                <div className="w-4 h-4 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" />
              )}
              {!isVerifying && verifiedName && (
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              )}
            </div>
          </div>

          {/* Nickname validation badge */}
          <AnimatePresence mode="wait">
            {verifiedName && (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                className="flex items-center gap-2 px-3 py-2 bg-emerald-950/40 border border-emerald-900/50 rounded-lg text-xs text-emerald-400"
              >
                <User className="w-3.5 h-3.5" />
                <span>
                  {t.idVerified} <strong>{verifiedName}</strong>
                </span>
                <ShieldCheck className="w-3.5 h-3.5 ml-auto text-emerald-400/80 animate-pulse" />
              </motion.div>
            )}
          </AnimatePresence>

          {errorMsg && (
            <p className="text-xs text-rose-400 mt-1 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
              {errorMsg}
            </p>
          )}
        </div>

        {/* Region Selector */}
        <div className="space-y-2">
          <label className="block text-xs font-semibold text-slate-400">
            {t.regionLabel} <span className="text-orange-500">*</span>
          </label>
          <select
            id="ff-region"
            value={region}
            onChange={(e) => setRegion(e.target.value)}
            className={`w-full bg-slate-950 border border-slate-800 text-slate-200 text-sm rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-orange-500/40 focus:border-orange-500/60 transition-all ${
              isRTL ? 'text-right' : 'text-left'
            }`}
          >
            <option value="" disabled className="text-slate-600">
              {t.selectRegion}
            </option>
            {regions.map((reg, idx) => (
              <option key={idx} value={reg} className="bg-slate-950 text-slate-300">
                {reg}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Step 2: Package Selection */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-orange-500 font-display font-semibold text-sm tracking-wider uppercase">
            <span className="flex items-center justify-center w-5 h-5 rounded-full bg-orange-500/10 text-xs border border-orange-500/20">2</span>
            {t.selectPackage}
          </div>
          <span className="text-[10px] text-slate-500 flex items-center gap-1">
            <HelpCircle className="w-3 h-3" /> FF ID top-up is instantaneous
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {((packages && packages.length > 0) ? packages : freefirePackages).map((pack) => {
            const isSelected = selectedPack?.id === pack.id;
            return (
              <motion.div
                key={pack.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setSelectedPack(pack)}
                className={`relative p-4 rounded-xl border cursor-pointer flex flex-col justify-between h-36 transition-all ${
                  isSelected
                    ? 'bg-gradient-to-br from-orange-950/20 to-amber-950/30 border-orange-500/90 shadow-[0_0_15px_rgba(249,115,22,0.15)]'
                    : 'bg-slate-950/80 border-slate-800/80 hover:border-slate-700/80'
                }`}
              >
                {/* Badge for discount/best value */}
                {pack.badge && (
                  <span className={`absolute -top-2.5 -right-1 px-2 py-0.5 text-[8px] font-bold rounded-md tracking-wider uppercase shadow ${
                    isSelected ? 'bg-orange-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                  }`}>
                    {pack.badge}
                  </span>
                )}

                <div className="space-y-1">
                  {/* Diamonds display */}
                  <div className="flex items-center gap-1">
                    <span className="text-lg font-bold text-slate-100 group-hover:text-white">
                      {pack.amount}
                    </span>
                    <span className="text-orange-400 text-xs font-semibold">💎</span>
                  </div>

                  {/* Bonus text */}
                  {pack.bonus && (
                    <div className="text-[10px] text-emerald-400 bg-emerald-950/40 border border-emerald-900/50 px-1.5 py-0.5 rounded w-max">
                      +{pack.bonus} {t.bonusText}
                    </div>
                  )}
                </div>

                <div className="mt-4 flex items-center justify-between border-t border-slate-900 pt-2.5">
                  <div className="text-[10px] text-slate-500 uppercase tracking-widest">{t.priceLabel}</div>
                  <div className="text-sm font-bold text-amber-400">
                    {t.currencySymbol}{pack.price.toFixed(2)}
                  </div>
                </div>

                {/* Subtle selection ring */}
                {isSelected && (
                  <span className="absolute bottom-2 right-2 flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-500"></span>
                  </span>
                )}
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Recharge CTA */}
      <motion.button
        id="btn-ff-submit"
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.99 }}
        type="submit"
        disabled={!playerId || !region || !selectedPack || isVerifying}
        className={`w-full py-4 px-6 rounded-2xl font-bold font-display text-sm tracking-wide transition-all shadow-lg flex items-center justify-center gap-2 ${
          playerId && region && selectedPack && !isVerifying
            ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 hover:shadow-orange-500/20 hover:shadow-xl cursor-pointer'
            : 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed'
        }`}
      >
        <span>{t.rechargeNow}</span>
        <span>•</span>
        <span>
          {t.currencySymbol}
          {selectedPack ? selectedPack.price.toFixed(2) : '0.00'}
        </span>
      </motion.button>
    </form>
  );
}
