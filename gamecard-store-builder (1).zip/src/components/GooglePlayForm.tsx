import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Language, RechargePackage } from '../types';
import { googlePlayPackages } from '../data';
import { HelpCircle, Mail, AlertTriangle } from 'lucide-react';

interface GooglePlayFormProps {
  lang: Language;
  t: any;
  onInitiateRecharge: (target: string, pack: RechargePackage, nickname: string, region: string) => void;
  packages?: RechargePackage[];
}

export default function GooglePlayForm({ lang, t, onInitiateRecharge, packages }: GooglePlayFormProps) {
  const [email, setEmail] = useState('');
  const [selectedPack, setSelectedPack] = useState<RechargePackage | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  const validateEmail = (emailVal: string) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(emailVal);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setErrorMsg(lang === 'en' ? 'Please enter a delivery email' : 'يرجى إدخال البريد الإلكتروني للتسليم');
      return;
    }
    if (!validateEmail(email)) {
      setErrorMsg(lang === 'en' ? 'Please enter a valid email address' : 'يرجى إدخال بريد إلكتروني صحيح');
      return;
    }
    if (!selectedPack) {
      setErrorMsg(lang === 'en' ? 'Please select a Google Play card' : 'يرجى اختيار فئة بطاقة جوجل بلاي');
      return;
    }

    setErrorMsg('');
    onInitiateRecharge(email, selectedPack, 'Digital Card Code Customer', 'Global Code Store');
  };

  const isRTL = lang === 'ar';

  return (
    <form id="googleplay-form" onSubmit={handleSubmit} className="space-y-6">
      {/* Step 1: Account Information */}
      <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 space-y-4 shadow-xl">
        <div className="flex items-center gap-2 text-emerald-400 font-display font-semibold text-sm tracking-wider uppercase">
          <span className="flex items-center justify-center w-5 h-5 rounded-full bg-emerald-500/10 text-xs border border-emerald-500/20">1</span>
          {lang === 'en' ? 'Digital Code Delivery' : 'بيانات تسليم البطاقة الرقمية'}
        </div>

        <div className="space-y-2">
          <label className="block text-xs font-semibold text-slate-400">
            {t.emailLabel} <span className="text-emerald-400">*</span>
          </label>
          <div className="relative">
            <input
              id="gp-email-input"
              type="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (errorMsg) setErrorMsg('');
              }}
              placeholder={t.emailPlaceholder}
              className={`w-full bg-slate-950 border text-sm rounded-xl py-3 px-4 ${
                isRTL ? 'pr-10' : 'pl-10'
              } text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/40 transition-all ${
                errorMsg ? 'border-rose-500/50' : 'border-slate-800 focus:border-emerald-500/60'
              } ${isRTL ? 'text-right' : 'text-left'}`}
            />
            <div className={`absolute top-1/2 -translate-y-1/2 ${isRTL ? 'right-3.5' : 'left-3.5'} text-slate-500`}>
              <Mail className="w-4 h-4" />
            </div>
          </div>

          <div className="flex items-start gap-2 p-3 bg-emerald-950/20 border border-emerald-900/40 rounded-xl">
            <AlertTriangle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <p className="text-[11px] text-emerald-400/90 leading-relaxed">
              {lang === 'en'
                ? 'Your Google Play code is generated instantly upon successful checkout. We also send a backup email containing the code.'
                : 'يتم إصدار كود جوجل بلاي فوراً عند الدفع بنجاح، كما نقوم بإرسال نسخة احتياطية من الكود إلى بريدك الإلكتروني.'}
            </p>
          </div>

          {errorMsg && (
            <p className="text-xs text-rose-400 mt-1 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
              {errorMsg}
            </p>
          )}
        </div>
      </div>

      {/* Step 2: Package Selection */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-emerald-400 font-display font-semibold text-sm tracking-wider uppercase">
            <span className="flex items-center justify-center w-5 h-5 rounded-full bg-emerald-500/10 text-xs border border-emerald-500/20">2</span>
            {t.selectPackage}
          </div>
          <span className="text-[10px] text-slate-500 flex items-center gap-1">
            <HelpCircle className="w-3 h-3" /> Select Google Play value card
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {((packages && packages.length > 0) ? packages : googlePlayPackages).map((pack) => {
            const isSelected = selectedPack?.id === pack.id;
            return (
              <motion.div
                key={pack.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setSelectedPack(pack)}
                className={`relative p-4 rounded-xl border cursor-pointer flex flex-col justify-between h-36 transition-all ${
                  isSelected
                    ? 'bg-gradient-to-br from-emerald-950/20 to-teal-950/20 border-emerald-500/90 shadow-[0_0_15px_rgba(16,185,129,0.15)]'
                    : 'bg-slate-950/80 border-slate-800/80 hover:border-slate-700/80'
                }`}
              >
                {/* Badge for discount/best value */}
                {pack.badge && (
                  <span className={`absolute -top-2.5 -right-1 px-2 py-0.5 text-[8px] font-bold rounded-md tracking-wider uppercase shadow ${
                    isSelected ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                  }`}>
                    {pack.badge}
                  </span>
                )}

                <div className="space-y-1">
                  {/* Gift Card Display */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-xl font-bold text-slate-100">
                      {t.currencySymbol}{pack.amount}
                    </span>
                    <span className="text-emerald-400 text-xs font-semibold">💳</span>
                  </div>

                  <div className="text-[10px] text-slate-400">
                    Google Play Card
                  </div>
                </div>

                <div className="mt-4 flex items-center justify-between border-t border-slate-900 pt-2.5">
                  <div className="text-[10px] text-slate-500 uppercase tracking-widest">{t.priceLabel}</div>
                  <div className="text-sm font-bold text-amber-400">
                    {t.currencySymbol}{pack.price.toFixed(2)}
                  </div>
                </div>

                {/* Subtle selection ring */}
                {isSelected && (
                  <span className="absolute bottom-2 right-2 flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                )}
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Recharge CTA */}
      <motion.button
        id="btn-gp-submit"
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.99 }}
        type="submit"
        disabled={!email || !validateEmail(email) || !selectedPack}
        className={`w-full py-4 px-6 rounded-2xl font-bold font-display text-sm tracking-wide transition-all shadow-lg flex items-center justify-center gap-2 ${
          email && validateEmail(email) && selectedPack
            ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 hover:shadow-emerald-500/20 hover:shadow-xl cursor-pointer'
            : 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed'
        }`}
      >
        <span>{t.rechargeNow}</span>
        <span>•</span>
        <span>
          {t.currencySymbol}
          {selectedPack ? selectedPack.price.toFixed(2) : '0.00'}
        </span>
      </motion.button>
    </form>
  );
}
