import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Language, GameType, RechargePackage, RechargeOrder } from '../types';
import { 
  X, 
  TrendingUp, 
  DollarSign, 
  ShoppingBag, 
  Activity, 
  Settings, 
  Database, 
  Plus, 
  Trash2, 
  Edit, 
  Check, 
  AlertCircle,
  Clock,
  ShieldAlert,
  ArrowUpDown,
  Sliders,
  FileText,
  Percent,
  RefreshCw
} from 'lucide-react';
import { freefirePackages, pubgPackages, googlePlayPackages } from '../data';

interface AdminPanelProps {
  lang: Language;
  onClose: () => void;
  packages: RechargePackage[];
  orders: RechargeOrder[];
  onUpdatePackages: (updated: RechargePackage[]) => void;
  onUpdateOrders: (updated: RechargeOrder[]) => void;
}

export default function AdminPanel({
  lang,
  onClose,
  packages,
  orders,
  onUpdatePackages,
  onUpdateOrders,
}: AdminPanelProps) {
  const [activeSubTab, setActiveSubTab] = useState<'dashboard' | 'packages' | 'orders' | 'settings'>('dashboard');
  const [selectedGameFilter, setSelectedGameFilter] = useState<GameType | 'all'>('all');
  const [orderStatusFilter, setOrderStatusFilter] = useState<RechargeOrder['status'] | 'all'>('all');

  // Form State for Adding/Editing Package
  const [editingPackageId, setEditingPackageId] = useState<string | null>(null);
  const [packGame, setPackGame] = useState<GameType>('freefire');
  const [packTitle, setPackTitle] = useState('');
  const [packAmount, setPackAmount] = useState<number>(100);
  const [packBonus, setPackBonus] = useState<number>(0);
  const [packPrice, setPackPrice] = useState<number>(1.99);
  const [packBadge, setPackBadge] = useState('');
  const [packError, setPackError] = useState('');
  const [packSuccessMsg, setPackSuccessMsg] = useState('');

  // Config settings stored in localStorage
  const [deliveryTime, setDeliveryTime] = useState(() => localStorage.getItem('store_delivery_time') || '1-3 Minutes');
  const [supportWhatsapp, setSupportWhatsapp] = useState(() => localStorage.getItem('store_support_whatsapp') || '+966 500 000 000');
  const [supportEmail, setSupportEmail] = useState(() => localStorage.getItem('store_support_email') || 'support@gamercard.com');
  const [botGreeting, setBotGreeting] = useState(() => localStorage.getItem('store_bot_greeting') || 'Welcome to GamerCard live support! How can we assist you today with your recharge?');
  const [successSaved, setSuccessSaved] = useState(false);

  // Stats calculation
  const totalOrders = orders.length;
  const completedOrders = orders.filter(o => o.status === 'completed').length;
  const pendingOrders = orders.filter(o => o.status === 'pending').length;
  const failedOrders = orders.filter(o => o.status === 'failed').length;

  const totalRevenue = orders
    .filter(o => o.status === 'completed')
    .reduce((sum, o) => sum + o.packagePrice, 0);

  // Sales by game
  const salesByGame = orders
    .filter(o => o.status === 'completed')
    .reduce((acc, o) => {
      const g = o.game;
      acc[g] = (acc[g] || 0) + o.packagePrice;
      return acc;
    }, {} as Record<GameType, number>);

  const handleSaveSettings = () => {
    localStorage.setItem('store_delivery_time', deliveryTime);
    localStorage.setItem('store_support_whatsapp', supportWhatsapp);
    localStorage.setItem('store_support_email', supportEmail);
    localStorage.setItem('store_bot_greeting', botGreeting);
    
    setSuccessSaved(true);
    setTimeout(() => setSuccessSaved(false), 3000);
  };

  // Package functions
  const handleAddOrEditPackage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!packTitle) {
      setPackError(lang === 'en' ? 'Package title is required' : 'اسم الباقة مطلوب');
      return;
    }
    if (packAmount <= 0 || packPrice <= 0) {
      setPackError(lang === 'en' ? 'Amount and Price must be positive values' : 'يجب أن تكون الكمية والسعر قيم موجبة');
      return;
    }

    if (editingPackageId) {
      // Edit mode
      const updated = packages.map(p => {
        if (p.id === editingPackageId) {
          return {
            ...p,
            game: packGame,
            title: packTitle,
            amount: packAmount,
            bonus: packBonus > 0 ? packBonus : undefined,
            price: packPrice,
            badge: packBadge || undefined
          };
        }
        return p;
      });
      onUpdatePackages(updated);
      setEditingPackageId(null);
      setPackSuccessMsg(lang === 'en' ? 'Package updated successfully!' : 'تم تحديث تفاصيل الباقة بنجاح!');
    } else {
      // Add mode
      const newPack: RechargePackage = {
        id: `pack_${Date.now()}`,
        game: packGame,
        title: packTitle,
        amount: packAmount,
        bonus: packBonus > 0 ? packBonus : undefined,
        price: packPrice,
        badge: packBadge || undefined
      };
      onUpdatePackages([...packages, newPack]);
      setPackSuccessMsg(lang === 'en' ? 'Package created successfully!' : 'تم إضافة الباقة الجديدة بنجاح!');
    }

    // Reset Form
    setPackTitle('');
    setPackAmount(100);
    setPackBonus(0);
    setPackPrice(1.99);
    setPackBadge('');
    setPackError('');
    setTimeout(() => setPackSuccessMsg(''), 4000);
  };

  const handleStartEditPackage = (p: RechargePackage) => {
    setEditingPackageId(p.id);
    setPackGame(p.game);
    setPackTitle(p.title);
    setPackAmount(p.amount);
    setPackBonus(p.bonus || 0);
    setPackPrice(p.price);
    setPackBadge(p.badge || '');
    setPackError('');
    setPackSuccessMsg('');

    // Smooth scroll the package form into view so the user instantly sees they are editing!
    setTimeout(() => {
      const element = document.getElementById('package-form');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 100);
  };

  const handleDeletePackage = (id: string) => {
    if (window.confirm(lang === 'en' ? 'Are you sure you want to delete this package?' : 'هل أنت متأكد من حذف هذه الباقة؟')) {
      const updated = packages.filter(p => p.id !== id);
      onUpdatePackages(updated);
    }
  };

  // Order status changes
  const handleUpdateOrderStatus = (orderId: string, newStatus: RechargeOrder['status']) => {
    const updated = orders.map(o => {
      if (o.id === orderId) {
        return { ...o, status: newStatus };
      }
      return o;
    });
    onUpdateOrders(updated);
  };

  const handleDeleteOrder = (orderId: string) => {
    if (window.confirm(lang === 'en' ? 'Are you sure you want to delete this order record?' : 'هل أنت متأكد من حذف سجل هذا الطلب؟')) {
      const updated = orders.filter(o => o.id !== orderId);
      onUpdateOrders(updated);
    }
  };

  const handleClearAllOrders = () => {
    if (window.confirm(lang === 'en' ? 'CRITICAL: Clear entire order history? This cannot be undone.' : 'تحذير هام: هل تريد مسح جميع سجلات الطلبات؟ لا يمكن التراجع عن هذه الخطوة.')) {
      onUpdateOrders([]);
    }
  };

  // Filter package and order lists
  const filteredPackages = packages.filter(p => selectedGameFilter === 'all' || p.game === selectedGameFilter);
  const filteredOrders = orders.filter(o => {
    const gameMatch = selectedGameFilter === 'all' || o.game === selectedGameFilter;
    const statusMatch = orderStatusFilter === 'all' || o.status === orderStatusFilter;
    return gameMatch && statusMatch;
  });

  // Arabic / English helper translation dictionary for Admin panel
  const adminT: Record<string, Record<Language, string>> = {
    title: { en: 'Admin Control Center', ar: 'لوحة تحكم المشرف الفائقة' },
    sub_title: { en: 'Manage packages, update order statuses, and view store performance in real time.', ar: 'إدارة باقات الشحن، تحديث حالات الطلبات، ومتابعة الأداء المالي والمبيعات.' },
    close: { en: 'Exit Panel', ar: 'خروج' },
    nav_dashboard: { en: 'Dashboard Overview', ar: 'مؤشرات الأداء' },
    nav_packages: { en: 'Package Manager', ar: 'إدارة باقات الشحن' },
    nav_orders: { en: 'Order Control', ar: 'التحكم بالطلبات' },
    nav_settings: { en: 'Store Settings', ar: 'إعدادات المتجر' },
    
    // Stats
    stat_revenue: { en: 'Total Revenue', ar: 'إجمالي الأرباح' },
    stat_orders: { en: 'Total Orders', ar: 'إجمالي الطلبات' },
    stat_completed: { en: 'Completed Recharges', ar: 'الطلبات المكتملة' },
    stat_pending: { en: 'Pending Verification', ar: 'طلبات قيد الانتظار' },
    
    // Package form
    add_title: { en: 'Add Recharge Package', ar: 'إضافة باقة شحن جديدة' },
    edit_title: { en: 'Edit Package Details', ar: 'تعديل تفاصيل الباقة' },
    form_game: { en: 'Select Game Type', ar: 'نوع اللعبة أو الخدمة' },
    form_pack_title: { en: 'Display Title (e.g. 520 Diamonds)', ar: 'اسم الباقة الظاهر (مثال: ٥٢٠ جوهرة)' },
    form_amount: { en: 'Base Amount (Numeric)', ar: 'الكمية الأساسية (رقمية)' },
    form_bonus: { en: 'Bonus Amount (Optional)', ar: 'الكمية الإضافية / بونص (اختياري)' },
    form_price: { en: 'Price (USD)', ar: 'السعر الإجمالي (بالدولار $)' },
    form_badge: { en: 'Custom Badge (e.g. Best Offer, +15% Extra)', ar: 'شارة مميزة (مثال: الأكثر مبيعاً، خصم خاص)' },
    btn_save: { en: 'Apply Changes', ar: 'حفظ وتطبيق الباقة' },
    btn_add: { en: 'Create Package', ar: 'إضافة الباقة للمتجر' },
    btn_cancel: { en: 'Cancel Edit', ar: 'إلغاء التعديل' },

    // Game Category translations
    freefire: { en: 'Free Fire', ar: 'فري فاير' },
    pubg: { en: 'PUBG Mobile', ar: 'ببجي موبايل' },
    googleplay: { en: 'Google Play Gift Card', ar: 'بطاقات جوجل بلاي' },
    all: { en: 'All Categories', ar: 'جميع الأقسام' },

    // Order table headers
    tbl_order_id: { en: 'Order ID', ar: 'رقم الطلب' },
    tbl_customer: { en: 'Customer Target', ar: 'بيانات التسليم / اللاعب' },
    tbl_package: { en: 'Package Purchased', ar: 'الباقة المشتراة' },
    tbl_price: { en: 'Paid Amount', ar: 'المبلغ المدفوع' },
    tbl_status: { en: 'Current Status', ar: 'حالة الطلب' },
    tbl_actions: { en: 'Actions', ar: 'الإجراءات السريعة' },
    tbl_date: { en: 'Date & Time', ar: 'التاريخ والوقت' },

    // Statuses
    pending: { en: 'Pending Review', ar: 'قيد المراجعة' },
    completed: { en: 'Completed Successfully', ar: 'مكتمل بنجاح' },
    failed: { en: 'Failed / Rejected', ar: 'مرفوض / فشل' },

    // Actions
    act_complete: { en: 'Approve & Charge', ar: 'قبول وشحن الحساب' },
    act_fail: { en: 'Reject / Refund', ar: 'رفض وإرجاع' },
    act_delete: { en: 'Delete Record', ar: 'حذف السجل' },

    // Settings
    set_deliv: { en: 'Average Delivery Time Displayed', ar: 'متوسط وقت التسليم المعروض للمشترين' },
    set_whatsapp: { en: 'Admin Support WhatsApp Number', ar: 'رقم دعم الواتساب الخاص بالمسؤول' },
    set_email: { en: 'Admin Email Contact', ar: 'البريد الإلكتروني للتواصل' },
    set_bot: { en: 'Live Chatbot Initial Greeting Message', ar: 'رسالة الترحيب التلقائية لدردشة الدعم المباشر' },
    set_save_btn: { en: 'Save Global Store Setup', ar: 'حفظ الإعدادات العامة للمتجر' },
    set_success: { en: 'Global configuration updated successfully!', ar: 'تم تحديث إعدادات المتجر بنجاح وتطبيقها على جميع العملاء!' },
  };

  const isRtl = lang === 'ar';

  return (
    <div className="fixed inset-0 bg-slate-950/98 backdrop-blur-md z-50 overflow-y-auto flex flex-col text-slate-100" style={{ direction: isRtl ? 'rtl' : 'ltr' }}>
      
      {/* Admin Header */}
      <header className="border-b border-slate-800 bg-slate-900/60 sticky top-0 backdrop-blur-md px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 z-10">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-rose-500 text-white text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-full animate-pulse">
              🛡️ Root Access
            </span>
            <h1 className="text-xl md:text-2xl font-bold font-sans tracking-tight text-white flex items-center gap-2">
              {adminT.title[lang]}
            </h1>
          </div>
          <p className="text-xs md:text-sm text-slate-400">
            {adminT.sub_title[lang]}
          </p>
        </div>

        <div className="flex items-center gap-3 self-end md:self-center">
          <button
            onClick={onClose}
            className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-lg font-medium text-xs md:text-sm transition-all duration-200 border border-slate-700 hover:border-slate-500"
          >
            <X size={16} />
            {adminT.close[lang]}
          </button>
        </div>
      </header>

      {/* Main Admin layout Grid */}
      <div className="flex-1 max-w-7xl mx-auto w-full p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Sidebar Navigation */}
        <nav className="lg:col-span-3 bg-slate-900/40 rounded-xl border border-slate-800/80 p-3 flex flex-row lg:flex-col gap-2 overflow-x-auto lg:overflow-visible">
          <button
            onClick={() => setActiveSubTab('dashboard')}
            className={`flex-1 lg:flex-none flex items-center justify-center lg:justify-start gap-3 px-4 py-3 rounded-lg text-xs md:text-sm font-semibold transition-all duration-200 whitespace-nowrap ${
              activeSubTab === 'dashboard' 
                ? 'bg-rose-600 text-white shadow-lg shadow-rose-900/20' 
                : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
            }`}
          >
            <TrendingUp size={18} />
            {adminT.nav_dashboard[lang]}
          </button>

          <button
            onClick={() => setActiveSubTab('packages')}
            className={`flex-1 lg:flex-none flex items-center justify-center lg:justify-start gap-3 px-4 py-3 rounded-lg text-xs md:text-sm font-semibold transition-all duration-200 whitespace-nowrap ${
              activeSubTab === 'packages' 
                ? 'bg-rose-600 text-white shadow-lg shadow-rose-900/20' 
                : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
            }`}
          >
            <Database size={18} />
            {adminT.nav_packages[lang]}
          </button>

          <button
            onClick={() => setActiveSubTab('orders')}
            className={`flex-1 lg:flex-none flex items-center justify-center lg:justify-start gap-3 px-4 py-3 rounded-lg text-xs md:text-sm font-semibold transition-all duration-200 relative whitespace-nowrap ${
              activeSubTab === 'orders' 
                ? 'bg-rose-600 text-white shadow-lg shadow-rose-900/20' 
                : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
            }`}
          >
            <ShoppingBag size={18} />
            <span className="flex items-center gap-1.5">
              {adminT.nav_orders[lang]}
              {pendingOrders > 0 && (
                <span className="inline-flex h-2 w-2 rounded-full bg-yellow-400 animate-ping" />
              )}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('settings')}
            className={`flex-1 lg:flex-none flex items-center justify-center lg:justify-start gap-3 px-4 py-3 rounded-lg text-xs md:text-sm font-semibold transition-all duration-200 whitespace-nowrap ${
              activeSubTab === 'settings' 
                ? 'bg-rose-600 text-white shadow-lg shadow-rose-900/20' 
                : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
            }`}
          >
            <Settings size={18} />
            {adminT.nav_settings[lang]}
          </button>
        </nav>

        {/* Dynamic Admin View Panel */}
        <main className="lg:col-span-9 flex flex-col gap-6">
          
          <AnimatePresence mode="wait">
            
            {/* TAB 1: DASHBOARD OVERVIEW */}
            {activeSubTab === 'dashboard' && (
              <motion.div
                key="dashboard"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex flex-col gap-6"
              >
                {/* Visual Sales Stats Row */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-slate-400">{adminT.stat_revenue[lang]}</span>
                      <DollarSign className="text-emerald-500" size={18} />
                    </div>
                    <div>
                      <span className="text-xl md:text-2xl font-bold font-mono text-emerald-400">
                        ${totalRevenue.toFixed(2)}
                      </span>
                      <span className="block text-[10px] text-slate-500 mt-1">From completed orders</span>
                    </div>
                  </div>

                  <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-slate-400">{adminT.stat_orders[lang]}</span>
                      <ShoppingBag className="text-rose-500" size={18} />
                    </div>
                    <div>
                      <span className="text-xl md:text-2xl font-bold font-mono text-white">
                        {totalOrders}
                      </span>
                      <span className="block text-[10px] text-slate-500 mt-1">Total placed on system</span>
                    </div>
                  </div>

                  <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-slate-400">{adminT.stat_completed[lang]}</span>
                      <Check className="text-sky-500" size={18} />
                    </div>
                    <div>
                      <span className="text-xl md:text-2xl font-bold font-mono text-sky-400">
                        {completedOrders}
                      </span>
                      <span className="block text-[10px] text-slate-500 mt-1">Successfully fulfilled</span>
                    </div>
                  </div>

                  <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-slate-400">{adminT.stat_pending[lang]}</span>
                      <Clock className="text-yellow-500 text-animate-pulse" size={18} />
                    </div>
                    <div>
                      <span className="text-xl md:text-2xl font-bold font-mono text-yellow-400">
                        {pendingOrders}
                      </span>
                      <span className="block text-[10px] text-slate-500 mt-1">Awaiting player delivery</span>
                    </div>
                  </div>
                </div>

                {/* Live Custom Dashboard Chart & Activity Log */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                  
                  {/* Revenue Distribution Chart */}
                  <div className="md:col-span-7 bg-slate-900/30 rounded-xl p-5 border border-slate-800/80 flex flex-col justify-between">
                    <div>
                      <h3 className="font-sans font-bold text-sm text-slate-300 mb-4 flex items-center gap-2">
                        <Activity size={16} className="text-rose-500" />
                        {lang === 'en' ? 'Fulfillment Distribution by Game' : 'توزيع الأرباح حسب الألعاب المكتملة'}
                      </h3>

                      {/* Pure CSS Visual Bar Chart */}
                      <div className="space-y-4 my-6">
                        {/* Free Fire */}
                        <div>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-slate-400 font-medium">🔥 Free Fire Diamonds</span>
                            <span className="text-slate-200 font-mono font-semibold">${(salesByGame['freefire'] || 0).toFixed(2)}</span>
                          </div>
                          <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-rose-500 rounded-full transition-all duration-1000" 
                              style={{ width: `${totalRevenue > 0 ? ((salesByGame['freefire'] || 0) / totalRevenue) * 100 : 0}%` }}
                            />
                          </div>
                        </div>

                        {/* PUBG */}
                        <div>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-slate-400 font-medium">🪙 PUBG Mobile UC</span>
                            <span className="text-slate-200 font-mono font-semibold">${(salesByGame['pubg'] || 0).toFixed(2)}</span>
                          </div>
                          <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-amber-500 rounded-full transition-all duration-1000" 
                              style={{ width: `${totalRevenue > 0 ? ((salesByGame['pubg'] || 0) / totalRevenue) * 100 : 0}%` }}
                            />
                          </div>
                        </div>

                        {/* Google Play */}
                        <div>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-slate-400 font-medium">💳 Google Play Cards</span>
                            <span className="text-slate-200 font-mono font-semibold">${(salesByGame['googleplay'] || 0).toFixed(2)}</span>
                          </div>
                          <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-emerald-500 rounded-full transition-all duration-1000" 
                              style={{ width: `${totalRevenue > 0 ? ((salesByGame['googleplay'] || 0) / totalRevenue) * 100 : 0}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="border-t border-slate-800 pt-3 flex justify-between items-center text-xs text-slate-500">
                      <span>{lang === 'en' ? 'Calculated automatically' : 'يتم احتساب الأرباح تلقائياً'}</span>
                      <span className="text-emerald-400 font-semibold flex items-center gap-1">
                        ● {lang === 'en' ? 'Live System Active' : 'النظام قيد التشغيل'}
                      </span>
                    </div>
                  </div>

                  {/* System Fast Actions */}
                  <div className="md:col-span-5 bg-slate-900/30 rounded-xl p-5 border border-slate-800/80 flex flex-col justify-between gap-4">
                    <div>
                      <h3 className="font-sans font-bold text-sm text-slate-300 mb-3 flex items-center gap-2">
                        <Sliders size={16} className="text-rose-500" />
                        {lang === 'en' ? 'Developer Fast Actions' : 'إجراءات سريعة للنظام'}
                      </h3>
                      <p className="text-xs text-slate-400 mb-4">
                        {lang === 'en' ? 'Manage quick system data parameters or wipe logs safely.' : 'التحكم الفوري في ذاكرة المتجر أو مسح الطلبات للتجربة.'}
                      </p>
                    </div>

                    <div className="space-y-2">
                      <button
                        onClick={() => {
                          // Seed demo orders for testing the dashboard
                          const demoOrders: RechargeOrder[] = [
                            {
                              id: 'RC-9982-1A',
                              game: 'freefire',
                              playerTarget: '489281923',
                              gameNickname: 'FF_ProGamer',
                              packageName: packages.find(p => p.game === 'freefire')?.title || '100 + 10 Diamonds',
                              packagePrice: packages.find(p => p.game === 'freefire')?.price || 0.99,
                              status: 'completed',
                              paymentMethod: 'card',
                              timestamp: new Date(Date.now() - 3600000 * 2).toISOString()
                            },
                            {
                              id: 'RC-3819-8B',
                              game: 'pubg',
                              playerTarget: '582019482',
                              gameNickname: 'PUBG_Sniper',
                              packageName: packages.find(p => p.game === 'pubg')?.title || '60 UC',
                              packagePrice: packages.find(p => p.game === 'pubg')?.price || 0.99,
                              status: 'pending',
                              paymentMethod: 'crypto',
                              timestamp: new Date(Date.now() - 600000).toISOString()
                            },
                            {
                              id: 'RC-7201-9C',
                              game: 'googleplay',
                              playerTarget: 'delivery@gamer.com',
                              gameNickname: 'Google Player',
                              packageName: packages.find(p => p.game === 'googleplay')?.title || '$10 Google Play Card',
                              packagePrice: packages.find(p => p.game === 'googleplay')?.price || 10.00,
                              status: 'completed',
                              paymentMethod: 'local_wallet',
                              timestamp: new Date(Date.now() - 3600000 * 24).toISOString()
                            }
                          ];
                          onUpdateOrders([...orders, ...demoOrders]);
                          alert(lang === 'en' ? 'Demo test orders generated successfully!' : 'تم إضافة طلبات تجريبية بنجاح لتجربة النظام!');
                        }}
                        className="w-full text-left py-2 px-3 bg-slate-800 hover:bg-slate-700/80 text-xs rounded-lg font-semibold text-rose-400 transition-all flex items-center gap-2 border border-slate-700/60"
                      >
                        <RefreshCw size={14} />
                        {lang === 'en' ? 'Inject Demo Orders for testing' : 'توليد طلبات عشوائية للتجربة'}
                      </button>

                      <button
                        onClick={handleClearAllOrders}
                        className="w-full text-left py-2 px-3 bg-rose-950/40 hover:bg-rose-900/40 text-xs rounded-lg font-semibold text-rose-300 transition-all flex items-center gap-2 border border-rose-900/60"
                      >
                        <Trash2 size={14} />
                        {lang === 'en' ? 'Clear All Customer Orders' : 'حذف وإفراغ جميع الطلبات'}
                      </button>

                      <button
                        onClick={() => {
                          if (window.confirm(lang === 'en' ? 'Are you sure you want to restore all packages to their original default list?' : 'هل أنت متأكد من استعادة الباقات الافتراضية الأصلية؟')) {
                            onUpdatePackages([...freefirePackages, ...pubgPackages, ...googlePlayPackages]);
                            alert(lang === 'en' ? 'All packages restored to default values successfully!' : 'تم استعادة الباقات الافتراضية بنجاح!');
                          }
                        }}
                        className="w-full text-left py-2 px-3 bg-emerald-950/40 hover:bg-emerald-900/40 text-xs rounded-lg font-semibold text-emerald-400 transition-all flex items-center gap-2 border border-emerald-900/60"
                      >
                        <RefreshCw size={14} className="text-emerald-500" />
                        {lang === 'en' ? 'Restore Default Packages' : 'استعادة الباقات الافتراضية'}
                      </button>
                    </div>

                    <div className="text-[10px] text-slate-500 bg-slate-900/80 p-2.5 rounded-lg border border-slate-800 mt-2">
                      🔐 {lang === 'en' ? 'All live data persists directly inside the client browser localStorage.' : 'يتم حفظ جميع التعديلات مباشرة في متصفحك الحالي عبر التخزين المحلي.'}
                    </div>
                  </div>

                </div>
              </motion.div>
            )}

            {/* TAB 2: PACKAGE MANAGER */}
            {activeSubTab === 'packages' && (
              <motion.div
                key="packages"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="grid grid-cols-1 md:grid-cols-12 gap-6"
              >
                {/* Form to Add/Edit */}
                <div 
                  id="package-form" 
                  className={`md:col-span-5 p-5 rounded-xl border flex flex-col gap-4 self-start transition-all duration-300 ${
                    editingPackageId 
                      ? 'bg-slate-900/70 border-amber-500 shadow-[0_0_20px_rgba(245,158,11,0.15)] ring-1 ring-amber-500/30' 
                      : 'bg-slate-900/40 border-slate-800'
                  }`}
                >
                  <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                    <h3 className="font-sans font-bold text-sm text-white flex items-center gap-2">
                      <Plus size={16} className={editingPackageId ? "text-amber-500" : "text-rose-500"} />
                      {editingPackageId ? adminT.edit_title[lang] : adminT.add_title[lang]}
                    </h3>
                    {editingPackageId && (
                      <button 
                        type="button"
                        onClick={() => {
                          setEditingPackageId(null);
                          setPackTitle('');
                          setPackAmount(100);
                          setPackBonus(0);
                          setPackPrice(1.99);
                          setPackBadge('');
                        }}
                        className="text-xs text-rose-400 hover:underline"
                      >
                        {adminT.btn_cancel[lang]}
                      </button>
                    )}
                  </div>

                  <form onSubmit={handleAddOrEditPackage} className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-400 mb-1.5">{adminT.form_game[lang]}</label>
                      <select
                        value={packGame}
                        onChange={(e) => setPackGame(e.target.value as GameType)}
                        className="w-full bg-slate-950/80 border border-slate-800 rounded-lg py-2 px-3 text-xs focus:ring-1 focus:ring-rose-500 focus:outline-none"
                      >
                        <option value="freefire">{adminT.freefire[lang]}</option>
                        <option value="pubg">{adminT.pubg[lang]}</option>
                        <option value="googleplay">{adminT.googleplay[lang]}</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-400 mb-1.5">{adminT.form_pack_title[lang]}</label>
                      <input
                        type="text"
                        placeholder="e.g. 520 + 50 Diamonds"
                        value={packTitle}
                        onChange={(e) => setPackTitle(e.target.value)}
                        className="w-full bg-slate-950/80 border border-slate-800 rounded-lg py-2 px-3 text-xs focus:ring-1 focus:ring-rose-500 focus:outline-none placeholder-slate-600 text-white"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-400 mb-1.5">{adminT.form_amount[lang]}</label>
                        <input
                          type="number"
                          value={packAmount}
                          onChange={(e) => setPackAmount(parseInt(e.target.value) || 0)}
                          className="w-full bg-slate-950/80 border border-slate-800 rounded-lg py-2 px-3 text-xs focus:ring-1 focus:ring-rose-500 focus:outline-none text-white"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-400 mb-1.5">{adminT.form_bonus[lang]}</label>
                        <input
                          type="number"
                          value={packBonus}
                          onChange={(e) => setPackBonus(parseInt(e.target.value) || 0)}
                          className="w-full bg-slate-950/80 border border-slate-800 rounded-lg py-2 px-3 text-xs focus:ring-1 focus:ring-rose-500 focus:outline-none text-white"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-400 mb-1.5">{adminT.form_price[lang]}</label>
                        <div className="relative">
                          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-500">$</span>
                          <input
                            type="number"
                            step="0.01"
                            value={packPrice}
                            onChange={(e) => setPackPrice(parseFloat(e.target.value) || 0)}
                            className="w-full bg-slate-950/80 border border-slate-800 rounded-lg py-2 pl-6 pr-3 text-xs focus:ring-1 focus:ring-rose-500 focus:outline-none text-white"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-400 mb-1.5">{adminT.form_badge[lang]}</label>
                        <input
                          type="text"
                          placeholder="Best Value"
                          value={packBadge}
                          onChange={(e) => setPackBadge(e.target.value)}
                          className="w-full bg-slate-950/80 border border-slate-800 rounded-lg py-2 px-3 text-xs focus:ring-1 focus:ring-rose-500 focus:outline-none placeholder-slate-600 text-white"
                        />
                      </div>
                    </div>

                    {packError && (
                      <div className="bg-rose-950/40 border border-rose-900/60 p-2.5 rounded-lg flex items-center gap-2 text-rose-300 text-xs">
                        <AlertCircle size={14} />
                        <span>{packError}</span>
                      </div>
                    )}

                    {packSuccessMsg && (
                      <div className="bg-emerald-950/50 border border-emerald-900/60 p-2.5 rounded-lg flex items-center gap-2 text-emerald-400 text-xs animate-pulse">
                        <Check size={14} />
                        <span>{packSuccessMsg}</span>
                      </div>
                    )}

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg font-bold text-xs transition-all duration-200 shadow-md shadow-rose-900/20 cursor-pointer"
                    >
                      {editingPackageId ? adminT.btn_save[lang] : adminT.btn_add[lang]}
                    </button>
                  </form>
                </div>

                {/* Packages Grid / List */}
                <div className="md:col-span-7 bg-slate-900/20 rounded-xl p-4 border border-slate-800/80">
                  
                  {/* Category Filter */}
                  <div className="flex gap-2 mb-4 overflow-x-auto pb-1">
                    <button
                      onClick={() => setSelectedGameFilter('all')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                        selectedGameFilter === 'all' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {adminT.all[lang]}
                    </button>
                    <button
                      onClick={() => setSelectedGameFilter('freefire')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                        selectedGameFilter === 'freefire' ? 'bg-rose-950 text-rose-300 border border-rose-900/40' : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {adminT.freefire[lang]}
                    </button>
                    <button
                      onClick={() => setSelectedGameFilter('pubg')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                        selectedGameFilter === 'pubg' ? 'bg-amber-950 text-amber-300 border border-amber-900/40' : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {adminT.pubg[lang]}
                    </button>
                    <button
                      onClick={() => setSelectedGameFilter('googleplay')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                        selectedGameFilter === 'googleplay' ? 'bg-emerald-950 text-emerald-300 border border-emerald-900/40' : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {adminT.googleplay[lang]}
                    </button>
                  </div>

                  {/* List items */}
                  <div className="space-y-3 max-h-[450px] overflow-y-auto pr-1">
                    {filteredPackages.length === 0 ? (
                      <div className="text-center py-12 text-slate-500 text-xs">
                        {lang === 'en' ? 'No packages found under this category' : 'لم يتم العثور على أي باقات في هذا القسم'}
                      </div>
                    ) : (
                      filteredPackages.map((p) => (
                        <div 
                          key={p.id}
                          className="bg-slate-900/40 p-3 rounded-xl border border-slate-800/80 flex items-center justify-between gap-4 transition-all hover:border-slate-700/80"
                        >
                          <div className="flex items-center gap-3">
                            <div className={`p-2 rounded-lg text-xs font-mono font-bold ${
                              p.game === 'freefire' ? 'bg-rose-950/60 text-rose-400' :
                              p.game === 'pubg' ? 'bg-amber-950/60 text-amber-400' :
                              'bg-emerald-950/60 text-emerald-400'
                            }`}>
                              {p.game === 'freefire' ? '💎' : p.game === 'pubg' ? '🪙' : '💳'}
                            </div>

                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-sans font-bold text-xs md:text-sm text-slate-100">{p.title}</span>
                                {p.badge && (
                                  <span className="text-[9px] bg-rose-600 text-white font-bold px-1.5 py-0.5 rounded-full">
                                    {p.badge}
                                  </span>
                                )}
                              </div>
                              <div className="text-[10px] text-slate-400 mt-0.5 font-mono">
                                {lang === 'en' ? 'Base' : 'الأساسي'}: {p.amount} 
                                {p.bonus ? ` | +${p.bonus} Bonus` : ''}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-3">
                            <span className="font-mono text-xs md:text-sm font-extrabold text-emerald-400 bg-slate-950/60 py-1 px-2 rounded">
                              ${p.price.toFixed(2)}
                            </span>

                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => handleStartEditPackage(p)}
                                className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-all cursor-pointer"
                                title={lang === 'en' ? 'Edit Package' : 'تعديل الباقة'}
                              >
                                <Edit size={14} />
                              </button>
                              <button
                                onClick={() => handleDeletePackage(p.id)}
                                className="p-1.5 hover:bg-rose-950/60 rounded-lg text-slate-400 hover:text-rose-400 transition-all cursor-pointer"
                                title={lang === 'en' ? 'Delete Package' : 'حذف الباقة'}
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                </div>
              </motion.div>
            )}

            {/* TAB 3: ORDER MANAGER */}
            {activeSubTab === 'orders' && (
              <motion.div
                key="orders"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex flex-col gap-4"
              >
                {/* Filters Row */}
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-slate-900/30 p-4 rounded-xl border border-slate-800">
                  <div className="flex flex-wrap gap-2">
                    {/* Game Filter */}
                    <select
                      value={selectedGameFilter}
                      onChange={(e) => setSelectedGameFilter(e.target.value as any)}
                      className="bg-slate-950 border border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-200 focus:outline-none cursor-pointer"
                    >
                      <option value="all">{lang === 'en' ? 'All Games' : 'كل الألعاب'}</option>
                      <option value="freefire">{adminT.freefire[lang]}</option>
                      <option value="pubg">{adminT.pubg[lang]}</option>
                      <option value="googleplay">{adminT.googleplay[lang]}</option>
                    </select>

                    {/* Status Filter */}
                    <select
                      value={orderStatusFilter}
                      onChange={(e) => setOrderStatusFilter(e.target.value as any)}
                      className="bg-slate-950 border border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-200 focus:outline-none cursor-pointer"
                    >
                      <option value="all">{lang === 'en' ? 'All Statuses' : 'جميع الحالات'}</option>
                      <option value="pending">{adminT.pending[lang]}</option>
                      <option value="completed">{adminT.completed[lang]}</option>
                      <option value="failed">{adminT.failed[lang]}</option>
                    </select>
                  </div>

                  <span className="text-xs text-slate-400 font-mono">
                    {lang === 'en' ? 'Found' : 'وجدنا'}: <strong>{filteredOrders.length}</strong> {lang === 'en' ? 'order records' : 'طلبات'}
                  </span>
                </div>

                {/* Orders List Container */}
                <div className="bg-slate-900/20 rounded-xl border border-slate-800/80 overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-300 border-collapse" style={{ direction: isRtl ? 'rtl' : 'ltr' }}>
                    <thead>
                      <tr className="bg-slate-900 border-b border-slate-800 text-slate-400">
                        <th className="px-4 py-3 text-right font-semibold">{adminT.tbl_order_id[lang]}</th>
                        <th className="px-4 py-3 text-right font-semibold">{adminT.tbl_date[lang]}</th>
                        <th className="px-4 py-3 text-right font-semibold">{adminT.tbl_customer[lang]}</th>
                        <th className="px-4 py-3 text-right font-semibold">{adminT.tbl_package[lang]}</th>
                        <th className="px-4 py-3 text-right font-semibold">{adminT.tbl_price[lang]}</th>
                        <th className="px-4 py-3 text-right font-semibold">{adminT.tbl_status[lang]}</th>
                        <th className="px-4 py-3 text-right font-semibold">{adminT.tbl_actions[lang]}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredOrders.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="text-center py-12 text-slate-500">
                            {lang === 'en' ? 'No orders registered on the system yet.' : 'لا توجد أي طلبات مسجلة على النظام حالياً.'}
                          </td>
                        </tr>
                      ) : (
                        filteredOrders.map((o) => (
                          <tr key={o.id} className="border-b border-slate-800/60 hover:bg-slate-900/30 transition-all">
                            <td className="px-4 py-4 font-mono font-bold text-rose-400 text-right">
                              {o.id}
                            </td>
                            <td className="px-4 py-4 text-slate-400 text-right">
                              {new Date(o.timestamp).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-US', {
                                hour: '2-digit',
                                minute: '2-digit',
                                month: 'short',
                                day: 'numeric'
                              })}
                            </td>
                            <td className="px-4 py-4 text-right">
                              <div className="font-semibold text-slate-100">{o.playerTarget}</div>
                              <div className="text-[10px] text-slate-400 mt-0.5">
                                {o.gameNickname || ''}
                              </div>
                            </td>
                            <td className="px-4 py-4 text-right">
                              <span className="font-medium text-slate-200">{o.packageName}</span>
                              <span className="block text-[10px] text-slate-500 font-mono capitalize">
                                {o.game}
                              </span>
                            </td>
                            <td className="px-4 py-4 font-mono font-bold text-slate-100 text-right">
                              ${o.packagePrice.toFixed(2)}
                            </td>
                            <td className="px-4 py-4 text-right">
                              <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold ${
                                o.status === 'completed' ? 'bg-emerald-950 text-emerald-400 border border-emerald-900/30' :
                                o.status === 'failed' ? 'bg-rose-950 text-rose-400 border border-rose-900/30' :
                                'bg-yellow-950 text-yellow-400 border border-yellow-900/30 animate-pulse'
                              }`}>
                                {adminT[o.status][lang]}
                              </span>
                            </td>
                            <td className="px-4 py-4 text-right">
                              <div className="flex items-center gap-1.5 justify-start">
                                {o.status === 'pending' && (
                                  <>
                                    <button
                                      onClick={() => handleUpdateOrderStatus(o.id, 'completed')}
                                      className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[10px] font-bold transition-all cursor-pointer flex items-center gap-1"
                                      title={adminT.act_complete[lang]}
                                    >
                                      <Check size={10} />
                                      {lang === 'en' ? 'Approve' : 'موافقة'}
                                    </button>
                                    <button
                                      onClick={() => handleUpdateOrderStatus(o.id, 'failed')}
                                      className="px-2 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded text-[10px] font-bold transition-all cursor-pointer flex items-center gap-1"
                                      title={adminT.act_fail[lang]}
                                    >
                                      <X size={10} />
                                      {lang === 'en' ? 'Reject' : 'رفض'}
                                    </button>
                                  </>
                                )}
                                <button
                                  onClick={() => handleDeleteOrder(o.id)}
                                  className="p-1.5 hover:bg-rose-950/80 text-slate-400 hover:text-rose-400 rounded transition-all cursor-pointer"
                                  title={adminT.act_delete[lang]}
                                >
                                  <Trash2 size={13} />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {/* TAB 4: GLOBAL SETTINGS */}
            {activeSubTab === 'settings' && (
              <motion.div
                key="settings"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-slate-900/40 p-5 rounded-xl border border-slate-800 max-w-2xl"
              >
                <div className="border-b border-slate-800 pb-3 mb-5">
                  <h3 className="font-sans font-bold text-sm text-white flex items-center gap-2">
                    <Settings size={16} className="text-rose-500" />
                    {lang === 'en' ? 'Global Store Configurations' : 'إعدادات المتجر العامة'}
                  </h3>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                      {adminT.set_deliv[lang]}
                    </label>
                    <input
                      type="text"
                      value={deliveryTime}
                      onChange={(e) => setDeliveryTime(e.target.value)}
                      placeholder="e.g., 1-5 Minutes"
                      className="w-full bg-slate-950/85 border border-slate-800 rounded-lg py-2 px-3 text-xs focus:ring-1 focus:ring-rose-500 focus:outline-none text-white"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                        {adminT.set_whatsapp[lang]}
                      </label>
                      <input
                        type="text"
                        value={supportWhatsapp}
                        onChange={(e) => setSupportWhatsapp(e.target.value)}
                        placeholder="+966 500 000 000"
                        className="w-full bg-slate-950/85 border border-slate-800 rounded-lg py-2 px-3 text-xs focus:ring-1 focus:ring-rose-500 focus:outline-none text-white font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                        {adminT.set_email[lang]}
                      </label>
                      <input
                        type="email"
                        value={supportEmail}
                        onChange={(e) => setSupportEmail(e.target.value)}
                        placeholder="support@example.com"
                        className="w-full bg-slate-950/85 border border-slate-800 rounded-lg py-2 px-3 text-xs focus:ring-1 focus:ring-rose-500 focus:outline-none text-white font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                      {adminT.set_bot[lang]}
                    </label>
                    <textarea
                      value={botGreeting}
                      onChange={(e) => setBotGreeting(e.target.value)}
                      rows={3}
                      className="w-full bg-slate-950/85 border border-slate-800 rounded-lg py-2 px-3 text-xs focus:ring-1 focus:ring-rose-500 focus:outline-none text-white resize-none"
                    />
                  </div>

                  {successSaved && (
                    <div className="bg-emerald-950/50 border border-emerald-900/60 p-3 rounded-lg flex items-center gap-2 text-emerald-300 text-xs transition-all">
                      <Check size={14} className="text-emerald-400" />
                      <span>{adminT.set_success[lang]}</span>
                    </div>
                  )}

                  <button
                    onClick={handleSaveSettings}
                    className="py-2.5 px-4 bg-rose-600 hover:bg-rose-500 text-white rounded-lg font-bold text-xs transition-all duration-200 shadow-md shadow-rose-900/20 cursor-pointer"
                  >
                    {adminT.set_save_btn[lang]}
                  </button>
                </div>
              </motion.div>
            )}

          </AnimatePresence>

        </main>

      </div>

    </div>
  );
}
