import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Language } from '../types';
import { supportFAQs } from '../data';
import { MessageSquare, Send, X, Bot, User, CornerDownLeft, Sparkles } from 'lucide-react';

interface SupportChatProps {
  lang: Language;
  t: any;
}

interface Message {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  time: string;
}

export default function SupportChat({ lang, t }: SupportChatProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [inputMessage, setInputMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Initialize with greeting
  useEffect(() => {
    const greetingEn = "Hello! I am GamerCharge's automated support assistant. How can I help you with your Free Fire, PUBG, or Google Play recharges today?";
    const greetingAr = "مرحباً بك! أنا المساعد الذكي لـ GamerCharge. كيف يمكنني مساعدتك في شحن جواهر فري فاير، شدات ببجي، أو بطاقات جوجل بلاي اليوم؟";
    
    setMessages([
      {
        id: 'greet',
        sender: 'bot',
        text: lang === 'en' ? greetingEn : greetingAr,
        time: new Date().toLocaleTimeString(lang === 'en' ? 'en-US' : 'ar-EG', { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  }, [lang]);

  // Keep chat scrolled to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping, isOpen]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const userText = inputMessage.trim();
    const timeStr = new Date().toLocaleTimeString(lang === 'en' ? 'en-US' : 'ar-EG', { hour: '2-digit', minute: '2-digit' });

    // 1. Add User Message
    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: userText,
      time: timeStr
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsTyping(true);

    // 2. Scan for keyword matching
    const query = userText.toLowerCase();
    let reply = '';

    const matchedFAQ = supportFAQs.find((faq) =>
      faq.keywords.some((keyword) => query.includes(keyword))
    );

    if (matchedFAQ) {
      reply = lang === 'en' ? matchedFAQ.replyEn : matchedFAQ.replyAr;
    } else {
      reply =
        lang === 'en'
          ? "Thank you for asking! For direct top-ups (Free Fire / PUBG), diamonds/UC credit inside 10 seconds of checkout. For gift codes, they are rendered on screen and emailed immediately. Please try using keywords like 'ID', 'refund', 'delay' or 'payment' so I can fetch exact procedures."
          : "شكراً لاستفسارك! لشحن الألعاب المباشر (فري فاير / ببجي)، تصل الشحنة تلقائياً خلال 10 ثوانٍ من الدفع. بالنسبة لبطاقات جوجل بلاي، تظهر الأكواد فوراً على الشاشة ونرسلها للبريد الإلكتروني. يرجى كتابة كلمات مثل 'معرف'، 'استرجاع'، 'تأخير'، أو 'طريقة الدفع' لتقديم تفاصيل أدق.";
    }

    // 3. Simulated response timer
    setTimeout(() => {
      setIsTyping(false);
      setMessages((prev) => [
        ...prev,
        {
          id: `bot-${Date.now()}`,
          sender: 'bot',
          text: reply,
          time: new Date().toLocaleTimeString(lang === 'en' ? 'en-US' : 'ar-EG', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }, 1000);
  };

  const isRTL = lang === 'ar';

  return (
    <>
      {/* Floating Action Button */}
      <motion.button
        id="btn-toggle-support"
        onClick={() => setIsOpen(!isOpen)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="fixed bottom-6 right-6 z-40 p-4 rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-xl shadow-teal-500/10 cursor-pointer flex items-center justify-center border border-emerald-400/30"
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageSquare className="w-6 h-6 animate-pulse" />}
      </motion.button>

      {/* Support Chat Drawer Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className={`fixed bottom-24 ${
              isRTL ? 'left-6 md:left-12' : 'right-6 md:right-12'
            } z-40 w-[90vw] max-w-sm h-[500px] bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden`}
          >
            {/* Chat Header */}
            <div className="bg-slate-950 p-4 border-b border-slate-850 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  <Bot className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-100 flex items-center gap-1">
                    {t.supportTitle}
                    <Sparkles className="w-3 h-3 text-amber-400" />
                  </h3>
                  <span className="text-[9px] text-emerald-400 font-semibold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                    Online | Support Bot
                  </span>
                </div>
              </div>
              <button
                id="btn-close-support"
                onClick={() => setIsOpen(false)}
                className="text-slate-500 hover:text-slate-300 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Chat Messages */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3.5 no-scrollbar bg-slate-950/20">
              {messages.map((msg) => {
                const isBot = msg.sender === 'bot';
                return (
                  <div
                    key={msg.id}
                    className={`flex items-end gap-2 ${isBot ? 'justify-start' : 'justify-end'}`}
                  >
                    {isBot && (
                      <div className="w-6 h-6 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-900/50 flex items-center justify-center text-[10px] shrink-0">
                        🤖
                      </div>
                    )}
                    <div className="flex flex-col max-w-[75%] space-y-1">
                      <div
                        className={`p-3 rounded-2xl text-xs leading-relaxed ${
                          isBot
                            ? 'bg-slate-900 text-slate-300 rounded-bl-none border border-slate-850'
                            : 'bg-emerald-500 text-slate-950 font-medium rounded-br-none'
                        }`}
                      >
                        {msg.text}
                      </div>
                      <span className={`text-[8px] text-slate-500 ${isBot ? 'text-left' : 'text-right'}`}>
                        {msg.time}
                      </span>
                    </div>
                  </div>
                );
              })}

              {isTyping && (
                <div className="flex items-end gap-2 justify-start">
                  <div className="w-6 h-6 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-900/50 flex items-center justify-center text-[10px]">
                    🤖
                  </div>
                  <div className="p-3 bg-slate-900 border border-slate-850 rounded-2xl rounded-bl-none flex items-center gap-1 py-4 px-5">
                    <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce" />
                    <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce delay-100" />
                    <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce delay-200" />
                  </div>
                </div>
              )}
            </div>

            {/* Quick Suggestions list */}
            <div className="px-4 py-2 bg-slate-950 border-t border-slate-850/60 overflow-x-auto whitespace-nowrap flex gap-1.5 no-scrollbar">
              {['Find ID', 'Pending topup', 'Refund info', 'Payment help'].map((keyword) => {
                const translated = lang === 'ar' 
                  ? keyword === 'Find ID' ? 'أين الـ ID؟' : keyword === 'Pending topup' ? 'الشحن متأخر؟' : keyword === 'Refund info' ? 'سياسة الاسترجاع' : 'طرق الدفع'
                  : keyword;
                return (
                  <button
                    id={`btn-suggest-${keyword.replace(' ', '-')}`}
                    key={keyword}
                    type="button"
                    onClick={() => {
                      setInputMessage(translated);
                    }}
                    className="text-[9px] font-semibold bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800 hover:border-slate-700 px-2.5 py-1 rounded-full transition-all"
                  >
                    {translated}
                  </button>
                );
              })}
            </div>

            {/* Chat Input */}
            <form onSubmit={handleSendMessage} className="p-3 bg-slate-950 border-t border-slate-850 flex items-center gap-2">
              <input
                id="support-chat-input"
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder={lang === 'en' ? 'Type a question...' : 'اكتب سؤالك هنا...'}
                className={`flex-1 bg-slate-900 border border-slate-800 text-xs rounded-xl py-2.5 px-3.5 focus:outline-none focus:ring-1 focus:ring-emerald-500/50 text-slate-200 ${
                  isRTL ? 'text-right' : 'text-left'
                }`}
              />
              <button
                id="btn-send-support-msg"
                type="submit"
                disabled={!inputMessage.trim() || isTyping}
                className="p-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 hover:opacity-95 transition-opacity disabled:opacity-40 disabled:cursor-not-allowed shrink-0 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
