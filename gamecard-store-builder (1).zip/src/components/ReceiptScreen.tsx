import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Language, RechargeOrder } from '../types';
import { paymentMethods } from '../data';
import { Check, Copy, ArrowLeft, Download, ShieldCheck, Gamepad2, Ticket } from 'lucide-react';

interface ReceiptScreenProps {
  lang: Language;
  t: any;
  order: RechargeOrder;
  onClose: () => void;
}

export default function ReceiptScreen({ lang, t, order, onClose }: ReceiptScreenProps) {
  const [copied, setCopied] = useState(false);

  const handleCopyCode = () => {
    if (order.redeemCode) {
      navigator.clipboard.writeText(order.redeemCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadInvoice = () => {
    // Simulate invoice download by invoking browser print
    window.print();
  };

  const currentPaymentMethod = paymentMethods.find((p) => p.id === order.paymentMethod);
  const paymentName = currentPaymentMethod
    ? lang === 'en'
      ? currentPaymentMethod.nameEn
      : currentPaymentMethod.nameAr
    : order.paymentMethod;

  const isRTL = lang === 'ar';

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 30 }}
      className="max-w-xl mx-auto bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl relative"
    >
      {/* Decorative Gaming Accents */}
      <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-500" />

      {/* Success Confetti Style Header */}
      <div className="p-8 text-center space-y-4 border-b border-slate-900 bg-slate-950/40 relative">
        <div className="mx-auto w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-lg shadow-emerald-500/15 relative">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', delay: 0.1, stiffness: 200 }}
          >
            <ShieldCheck className="w-8 h-8" />
          </motion.div>
          <span className="absolute -top-1.5 -right-1.5 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
          </span>
        </div>

        <div className="space-y-1">
          <h2 className="text-2xl font-black font-display tracking-tight text-slate-100">
            {t.successTitle}
          </h2>
          <p className="text-xs text-slate-400">{t.successSub}</p>
        </div>
      </div>

      {/* Ticket Body with Decorative Punch Cut Outs */}
      <div className="p-8 space-y-6 relative">
        {/* Left Cut */}
        <div className="absolute top-0 -left-4 w-8 h-8 rounded-full bg-slate-950 border-r border-slate-800 z-10" />
        {/* Right Cut */}
        <div className="absolute top-0 -right-4 w-8 h-8 rounded-full bg-slate-950 border-l border-slate-800 z-10" />

        {/* Dash Line */}
        <div className="absolute top-3.5 inset-x-8 border-t border-dashed border-slate-800" />

        {/* Redeem Code Delivery Panel (Only for Google Play) */}
        {order.redeemCode && (
          <div className="bg-slate-950 border border-emerald-500/30 rounded-2xl p-5 space-y-3.5 relative overflow-hidden shadow-[0_0_15px_rgba(16,185,129,0.05)]">
            <div className="absolute -right-8 -bottom-8 text-emerald-500/5 rotate-12">
              <Ticket className="w-24 h-24" />
            </div>

            <div className="text-center space-y-1">
              <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest block">
                {t.googlePlayCode}
              </span>
              <p className="text-xs text-slate-500">
                {lang === 'en'
                  ? 'Redeem this code inside your Google Play store account'
                  : 'قم بتنشيط هذا الكود مباشرةً داخل حساب متجر جوجل بلاي الخاص بك'}
              </p>
            </div>

            <div className="flex items-center justify-between bg-slate-900 border border-slate-800 px-4 py-3.5 rounded-xl">
              <span className="font-mono font-bold text-slate-200 tracking-wider text-sm sm:text-base select-all select-none">
                {order.redeemCode}
              </span>
              <button
                id="btn-copy-redeem-code"
                onClick={handleCopyCode}
                className="flex items-center gap-1 text-xs font-semibold bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 px-3 py-1.5 rounded-lg transition-all"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>{t.codeCopied}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>{t.copyCode}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Direct Recharge details (Free Fire / PUBG) */}
        {!order.redeemCode && (
          <div className="bg-slate-950/60 border border-slate-850 p-5 rounded-2xl flex items-center gap-4 relative overflow-hidden">
            <div className="p-3.5 rounded-xl bg-orange-500/10 text-orange-400 border border-orange-500/20">
              <Gamepad2 className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">
                {lang === 'en' ? 'Direct Game Delivery Log' : 'تقرير تسليم الشحن المباشر'}
              </span>
              <h4 className="text-sm font-bold text-slate-200">
                {lang === 'en' ? 'Account credit authorized successfully' : 'تم اعتماد رصيد الحساب بنجاح'}
              </h4>
              <p className="text-xs text-slate-400 mt-1">
                {lang === 'en'
                  ? 'Synced with core gaming network. Character is ready.'
                  : 'تم المزامنة مع سيرفرات اللعبة. رصيدك جاهز للاستخدام الآن.'}
              </p>
            </div>
          </div>
        )}

        {/* Metadata Details Grid */}
        <div className="space-y-3.5 border-t border-slate-900 pt-5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-500">{t.transactionID}</span>
            <span className="font-mono font-bold text-slate-300">{order.id}</span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-500">{t.targetDetails}</span>
            <span className="font-mono font-semibold text-slate-200">{order.playerTarget}</span>
          </div>

          {order.gameNickname && order.gameNickname !== 'Digital Card Code Customer' && (
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">{t.idVerified}</span>
              <span className="font-semibold text-emerald-400">{order.gameNickname}</span>
            </div>
          )}

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-500">{t.packageDetails}</span>
            <span className="font-semibold text-slate-200">{order.packageName}</span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-500">{lang === 'en' ? 'Payment Gateway' : 'بوابة الدفع الإلكتروني'}</span>
            <span className="text-slate-300">{paymentName}</span>
          </div>

          {order.txnHash && (
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">{lang === 'en' ? 'Ledger Hash' : 'رمز توثيق المعاملة'}</span>
              <span className="font-mono text-slate-400 truncate max-w-[180px] text-right" title={order.txnHash}>
                {order.txnHash}
              </span>
            </div>
          )}

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-500">{t.dateLabel}</span>
            <span className="text-slate-300">{order.timestamp}</span>
          </div>

          {/* Pricing Box */}
          <div className="flex items-center justify-between p-4 bg-slate-950 border border-slate-850 rounded-xl mt-4">
            <span className="text-xs font-semibold text-slate-400">{t.totalPaid}</span>
            <span className="text-xl font-black text-amber-400">
              {t.currencySymbol}{order.packagePrice.toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {/* Footer CTAs */}
      <div className="p-6 bg-slate-950 border-t border-slate-900 flex flex-col sm:flex-row gap-3">
        <button
          id="btn-invoice-download"
          onClick={handleDownloadInvoice}
          className="flex-1 py-3 px-4 rounded-xl text-xs font-semibold bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-slate-100 transition-all flex items-center justify-center gap-1.5"
        >
          <Download className="w-4 h-4" />
          <span>{lang === 'en' ? 'Print / Save Invoice' : 'طباعة / حفظ الفاتورة'}</span>
        </button>
        <button
          id="btn-invoice-close"
          onClick={onClose}
          className="flex-1 py-3 px-4 rounded-xl text-xs font-bold bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <ArrowLeft className={`w-4 h-4 ${isRTL ? 'rotate-180' : ''}`} />
          <span>{t.closeReceipt}</span>
        </button>
      </div>
    </motion.div>
  );
}
