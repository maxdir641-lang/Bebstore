import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Language, RechargePackage, PaymentMethodId, RechargeOrder } from '../types';
import { paymentMethods, generateTxnId, generateGooglePlayCode } from '../data';
import { CreditCard, Wallet, Coins, PhoneCall, X, ShieldAlert, CheckCircle2, Clipboard, Loader2, Sparkles } from 'lucide-react';

interface CheckoutModalProps {
  lang: Language;
  t: any;
  isOpen: boolean;
  onClose: () => void;
  target: string;
  gameNickname: string;
  region: string;
  selectedPack: RechargePackage;
  onPaymentSuccess: (order: RechargeOrder) => void;
}

export default function CheckoutModal({
  lang,
  t,
  isOpen,
  onClose,
  target,
  gameNickname,
  region,
  selectedPack,
  onPaymentSuccess,
}: CheckoutModalProps) {
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethodId>('card');
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStep, setProcessingStep] = useState(0);

  // Form Inputs
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvc, setCardCvc] = useState('');
  const [paypalEmail, setPaypalEmail] = useState('');
  const [walletNumber, setWalletNumber] = useState('');
  const [isCopied, setIsCopied] = useState(false);

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || '';
    const parts = [];

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }

    if (parts.length > 0) {
      return parts.join(' ');
    } else {
      return v;
    }
  };

  const handleCopyCrypto = () => {
    navigator.clipboard.writeText('TUp19y8P28N1sV72hC91sJ7P2n19z76');
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setProcessingStep(0);

    // Multi-step loading process for extreme realism
    const steps = [
      lang === 'en' ? 'Verifying payment secure handshake...' : 'جاري التحقق من اتصال بوابة الدفع الآمنة...',
      lang === 'en' ? 'Authorizing fund allocation...' : 'جاري مراجعة الرصيد المتاح...',
      lang === 'en' ? 'Broadcasting direct top-up to game API...' : 'جاري إرسال حزم الشحن إلى سيرفر اللعبة...',
      lang === 'en' ? 'Generating secure voucher receipts...' : 'جاري إصدار أكواد بطاقة الشحن الإلكترونية...'
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      currentStep++;
      if (currentStep < steps.length) {
        setProcessingStep(currentStep);
      } else {
        clearInterval(interval);
        
        // Finalize transaction and write order
        const newOrder: RechargeOrder = {
          id: generateTxnId(),
          game: selectedPack.game,
          playerTarget: target,
          packageName: selectedPack.title,
          packagePrice: selectedPack.price,
          paymentMethod: selectedMethod,
          timestamp: new Date().toLocaleString(lang === 'en' ? 'en-US' : 'ar-EG'),
          status: 'completed',
          gameNickname: gameNickname || undefined,
          redeemCode: selectedPack.game === 'googleplay' ? generateGooglePlayCode() : undefined,
          txnHash: selectedMethod === 'crypto' ? '0x' + Array.from({length: 40}, () => '0123456789abcdef'[Math.floor(Math.random() * 16)]).join('') : undefined
        };

        setIsProcessing(false);
        onPaymentSuccess(newOrder);
      }
    }, 1200);
  };

  if (!isOpen) return null;

  const isRTL = lang === 'ar';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-800">
          <div>
            <h2 className="text-xl font-bold font-display text-slate-100 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-emerald-400" />
              {t.checkoutTitle}
            </h2>
            <p className="text-xs text-slate-400 mt-1">{t.checkoutSub}</p>
          </div>
          {!isProcessing && (
            <button
              id="btn-close-checkout"
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto no-scrollbar p-6 space-y-6">
          {isProcessing ? (
            /* Immersive Loading Screen */
            <div className="flex flex-col items-center justify-center py-12 space-y-6">
              <div className="relative flex items-center justify-center">
                <Loader2 className="w-16 h-16 text-emerald-400 animate-spin" />
                <span className="absolute text-xl">💳</span>
              </div>
              <div className="text-center space-y-2">
                <h3 className="text-lg font-bold font-display text-slate-100">
                  {t.processingText}
                </h3>
                <motion.p
                  key={processingStep}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-xs text-emerald-400 font-mono"
                >
                  {processingStep === 0 && (lang === 'en' ? 'Verifying payment secure handshake...' : 'جاري التحقق من اتصال بوابة الدفع الآمنة...')}
                  {processingStep === 1 && (lang === 'en' ? 'Authorizing fund allocation...' : 'جاري مراجعة الرصيد المتاح...')}
                  {processingStep === 2 && (lang === 'en' ? 'Broadcasting direct top-up to game API...' : 'جاري إرسال حزم الشحن إلى سيرفر اللعبة...')}
                  {processingStep === 3 && (lang === 'en' ? 'Generating secure voucher receipts...' : 'جاري إصدار أكواد بطاقة الشحن الإلكترونية...')}
                </motion.p>
              </div>
            </div>
          ) : (
            <>
              {/* Top-up Confirmation Panel */}
              <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-5 space-y-3.5">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                  {t.confirmDetails}
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm border-t border-slate-900 pt-3">
                  <div>
                    <span className="text-xs text-slate-500 block">{t.targetDetails}</span>
                    <span className="font-mono font-semibold text-slate-200">{target}</span>
                  </div>
                  <div>
                    <span className="text-xs text-slate-500 block">{lang === 'en' ? 'Game / Platform' : 'اللعبة / المنصة'}</span>
                    <span className="font-semibold text-slate-200 capitalize">
                      {selectedPack.game === 'freefire' ? 'Free Fire' : selectedPack.game === 'pubg' ? 'PUBG Mobile' : 'Google Play Card'}
                    </span>
                  </div>
                  {gameNickname && gameNickname !== 'Digital Card Code Customer' && (
                    <div>
                      <span className="text-xs text-slate-500 block">{lang === 'en' ? 'Verified Account' : 'الحساب الموثق'}</span>
                      <span className="font-semibold text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        {gameNickname}
                      </span>
                    </div>
                  )}
                  {region && (
                    <div>
                      <span className="text-xs text-slate-500 block">{t.regionLabel}</span>
                      <span className="text-xs text-slate-300 font-medium">{region}</span>
                    </div>
                  )}
                </div>

                <div className="border-t border-slate-900 pt-3 flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="text-xs text-slate-500">{t.packageDetails}</span>
                    <span className="font-bold text-slate-200">{selectedPack.title}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-slate-500 block">{t.priceLabel}</span>
                    <span className="text-xl font-black text-amber-400">
                      {t.currencySymbol}{selectedPack.price.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Payment Methods Selection */}
              <div className="space-y-3">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                  {t.paymentMethodTitle}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {paymentMethods.map((method) => {
                    const isSelected = selectedMethod === method.id;
                    return (
                      <div
                        key={method.id}
                        onClick={() => setSelectedMethod(method.id)}
                        className={`p-4 rounded-xl border cursor-pointer flex gap-3 transition-all ${
                          isSelected
                            ? 'bg-slate-950 border-emerald-500/80 shadow-[0_0_10px_rgba(16,185,129,0.08)]'
                            : 'bg-slate-950/40 border-slate-800/80 hover:border-slate-800 hover:bg-slate-950'
                        }`}
                      >
                        <div className={`p-2 h-max rounded-lg ${isSelected ? 'bg-emerald-950 text-emerald-400' : 'bg-slate-900 text-slate-400'}`}>
                          {method.icon === 'CreditCard' && <CreditCard className="w-4 h-4" />}
                          {method.icon === 'Wallet' && <Wallet className="w-4 h-4" />}
                          {method.icon === 'PhoneCall' && <PhoneCall className="w-4 h-4" />}
                          {method.icon === 'Coins' && <Coins className="w-4 h-4" />}
                        </div>
                        <div className="space-y-1">
                          <h4 className="text-xs font-bold text-slate-200">
                            {lang === 'en' ? method.nameEn : method.nameAr}
                          </h4>
                          <p className="text-[10px] text-slate-500 leading-normal">
                            {lang === 'en' ? method.descriptionEn : method.descriptionAr}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Secure Form Body */}
              <form onSubmit={handlePay} className="border-t border-slate-800 pt-6 space-y-4">
                {selectedMethod === 'card' && (
                  <div className="space-y-3">
                    <div className="space-y-1.5">
                      <label className="block text-[11px] text-slate-400 font-semibold">{t.cardNumber}</label>
                      <input
                        id="checkout-card-num"
                        type="text"
                        required
                        value={cardNumber}
                        onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                        maxLength={19}
                        placeholder="4123 4567 8901 2345"
                        className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-sm rounded-xl py-3 px-4 focus:outline-none focus:ring-1 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all font-mono"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="block text-[11px] text-slate-400 font-semibold">{t.cardExpiry}</label>
                        <input
                          id="checkout-card-expiry"
                          type="text"
                          required
                          value={cardExpiry}
                          onChange={(e) => {
                            let val = e.target.value.replace(/\D/g, '');
                            if (val.length > 2) val = val.substring(0, 2) + '/' + val.substring(2, 4);
                            setCardExpiry(val);
                          }}
                          maxLength={5}
                          placeholder="MM/YY"
                          className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-sm rounded-xl py-3 px-4 focus:outline-none focus:ring-1 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all font-mono text-center"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="block text-[11px] text-slate-400 font-semibold">{t.cardCVC}</label>
                        <input
                          id="checkout-card-cvc"
                          type="password"
                          required
                          value={cardCvc}
                          onChange={(e) => setCardCvc(e.target.value.replace(/\D/g, ''))}
                          maxLength={3}
                          placeholder="***"
                          className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-sm rounded-xl py-3 px-4 focus:outline-none focus:ring-1 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all font-mono text-center"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {selectedMethod === 'paypal' && (
                  <div className="space-y-1.5">
                    <label className="block text-[11px] text-slate-400 font-semibold">{t.paypalEmail}</label>
                    <input
                      id="checkout-paypal-email"
                      type="email"
                      required
                      value={paypalEmail}
                      onChange={(e) => setPaypalEmail(e.target.value)}
                      placeholder="billing-address@paypal.com"
                      className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-sm rounded-xl py-3 px-4 focus:outline-none focus:ring-1 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all"
                    />
                  </div>
                )}

                {selectedMethod === 'local_wallet' && (
                  <div className="space-y-3">
                    <div className="space-y-1.5">
                      <label className="block text-[11px] text-slate-400 font-semibold">{t.localWalletNumber}</label>
                      <input
                        id="checkout-wallet-num"
                        type="text"
                        required
                        value={walletNumber}
                        onChange={(e) => setWalletNumber(e.target.value.replace(/\D/g, ''))}
                        maxLength={11}
                        placeholder="01012345678"
                        className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-sm rounded-xl py-3 px-4 focus:outline-none focus:ring-1 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all font-mono"
                      />
                    </div>
                    <p className="text-[10px] text-slate-500 italic leading-normal">
                      {t.localWalletNotice}
                    </p>
                  </div>
                )}

                {selectedMethod === 'crypto' && (
                  <div className="space-y-3.5 bg-slate-950/60 p-4 border border-slate-850 rounded-xl">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-400 font-medium">{t.cryptoAddress}</span>
                      <span className="text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full">TRON Network</span>
                    </div>
                    <div className="flex items-center gap-2 bg-slate-950 border border-slate-850 p-3 rounded-lg">
                      <span className="text-xs text-slate-300 font-mono select-all overflow-x-auto whitespace-nowrap grow no-scrollbar">
                        TUp19y8P28N1sV72hC91sJ7P2n19z76
                      </span>
                      <button
                        id="btn-copy-crypto-addr"
                        type="button"
                        onClick={handleCopyCrypto}
                        className="p-1 rounded bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
                      >
                        <Clipboard className="w-4 h-4" />
                      </button>
                    </div>
                    <AnimatePresence>
                      {isCopied && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="text-xs text-emerald-400 text-center font-semibold"
                        >
                          {t.codeCopied}
                        </motion.div>
                      )}
                    </AnimatePresence>
                    <p className="text-[10px] text-slate-500 leading-normal">
                      {t.cryptoNotice}
                    </p>
                  </div>
                )}

                {/* Secure Badge */}
                <div className="flex items-center gap-2 bg-slate-950/40 p-3 rounded-xl border border-slate-850 text-[10px] text-slate-400 leading-relaxed justify-center">
                  <ShieldAlert className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>
                    {lang === 'en'
                      ? 'Secure SSL Connection. Payments are encrypted and fully private.'
                      : 'اتصال مشفر وآمن بالكامل بنظام SSL. بيانات دفعك مشفرة ومحمية.'}
                  </span>
                </div>

                {/* Proceed button */}
                <motion.button
                  id="btn-checkout-confirm"
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  type="submit"
                  className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold font-display py-4 px-6 rounded-2xl text-sm shadow-xl shadow-teal-500/10 hover:shadow-teal-500/20 cursor-pointer transition-all flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  {t.processPayment}
                </motion.button>
              </form>
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
}
