import { motion } from 'motion/react';
import { Language } from '../types';
import { Globe } from 'lucide-react';

interface LanguageToggleProps {
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
}

export default function LanguageToggle({ currentLanguage, onLanguageChange }: LanguageToggleProps) {
  return (
    <div className="flex items-center gap-2 bg-slate-900/60 border border-slate-800 p-1.5 rounded-full shadow-inner">
      <Globe className="w-4 h-4 text-emerald-400 ml-1.5 mr-0.5" />
      <button
        id="btn-lang-en"
        onClick={() => onLanguageChange('en')}
        className={`relative px-4 py-1.5 text-xs font-semibold rounded-full transition-colors duration-200 z-10 ${
          currentLanguage === 'en' ? 'text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        {currentLanguage === 'en' && (
          <motion.div
            layoutId="activeLang"
            className="absolute inset-0 bg-gradient-to-r from-emerald-400 to-teal-400 rounded-full -z-10 shadow-lg shadow-teal-500/20"
            transition={{ type: 'spring', stiffness: 380, damping: 30 }}
          />
        )}
        English
      </button>
      <button
        id="btn-lang-ar"
        onClick={() => onLanguageChange('ar')}
        className={`relative px-4 py-1.5 text-xs font-semibold rounded-full transition-colors duration-200 z-10 ${
          currentLanguage === 'ar' ? 'text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        {currentLanguage === 'ar' && (
          <motion.div
            layoutId="activeLang"
            className="absolute inset-0 bg-gradient-to-r from-teal-400 to-emerald-400 rounded-full -z-10 shadow-lg shadow-teal-500/20"
            transition={{ type: 'spring', stiffness: 380, damping: 30 }}
          />
        )}
        العربية
      </button>
    </div>
  );
}
