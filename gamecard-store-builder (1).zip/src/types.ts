export type Language = 'en' | 'ar';

export type GameType = 'freefire' | 'pubg' | 'googleplay';

export interface RechargePackage {
  id: string;
  game: GameType;
  title: string; // e.g. "100 + 10 Diamonds" or "325 UC"
  amount: number; // Base amount
  bonus?: number; // Bonus amount
  price: number;  // Price in USD
  badge?: string; // e.g., "Best Value", "Hot"
  imageUrl?: string;
}

export type PaymentMethodId = 'card' | 'paypal' | 'crypto' | 'local_wallet';

export interface PaymentMethod {
  id: PaymentMethodId;
  nameEn: string;
  nameAr: string;
  icon: string;
  descriptionEn: string;
  descriptionAr: string;
}

export interface RechargeOrder {
  id: string;
  game: GameType;
  playerTarget: string; // Player ID, Character ID, or Email
  packageName: string;
  packagePrice: number;
  paymentMethod: PaymentMethodId;
  timestamp: string;
  status: 'pending' | 'completed' | 'failed';
  gameNickname?: string; // Looked up nickname
  redeemCode?: string; // For Google Play cards
  txnHash?: string; // Sim transaction code
}

export interface TranslationDictionary {
  appName: string;
  subtitle: string;
  tagline: string;
  selectGame: string;
  freefireTitle: string;
  pubgTitle: string;
  googlePlayTitle: string;
  freefireDesc: string;
  pubgDesc: string;
  googlePlayDesc: string;
  playerIDLabel: string;
  playerIDPlaceholder: string;
  characterIDLabel: string;
  characterIDPlaceholder: string;
  emailLabel: string;
  emailPlaceholder: string;
  regionLabel: string;
  selectRegion: string;
  selectPackage: string;
  bonusText: string;
  priceLabel: string;
  rechargeNow: string;
  checkoutTitle: string;
  checkoutSub: string;
  confirmDetails: string;
  paymentMethodTitle: string;
  cardNumber: string;
  cardExpiry: string;
  cardCVC: string;
  paypalEmail: string;
  cryptoAddress: string;
  cryptoNotice: string;
  localWalletNumber: string;
  localWalletNotice: string;
  processPayment: string;
  processingText: string;
  verifyNickname: string;
  verifyingID: string;
  idVerified: string;
  idNotFound: string;
  successTitle: string;
  successSub: string;
  transactionID: string;
  targetDetails: string;
  packageDetails: string;
  deliveredTo: string;
  googlePlayCode: string;
  copyCode: string;
  codeCopied: string;
  closeReceipt: string;
  orderHistoryTitle: string;
  noOrders: string;
  statusCompleted: string;
  statusPending: string;
  statusFailed: string;
  dateLabel: string;
  supportTitle: string;
  supportHelp: string;
  needHelp: string;
  viewHistory: string;
  home: string;
  currencySymbol: string;
  searchHistoryPlaceholder: string;
  totalPaid: string;
}

export const translations: Record<Language, TranslationDictionary> = {
  en: {
    appName: "GamerCharge",
    subtitle: "Premium Game Card & Top-Up Center",
    tagline: "Instant, safe, and automated recharge for your favorite games.",
    selectGame: "Select Game or Card",
    freefireTitle: "Free Fire Diamonds",
    pubgTitle: "PUBG Mobile UC",
    googlePlayTitle: "Google Play Gift Cards",
    freefireDesc: "Direct top-up to your Player ID. Instant in-game delivery.",
    pubgDesc: "Direct character UC credit. Safe & official authorization.",
    googlePlayDesc: "Digital gift codes. Delivered instantly via screen & email.",
    playerIDLabel: "Free Fire Player ID",
    playerIDPlaceholder: "Enter your numerical Player ID (e.g., 482910482)",
    characterIDLabel: "PUBG Character ID",
    characterIDPlaceholder: "Enter your numeric Character ID (e.g., 51928374)",
    emailLabel: "Delivery Email Address",
    emailPlaceholder: "Enter email to receive code (e.g., alex@gmail.com)",
    regionLabel: "Server / Country Region",
    selectRegion: "Select regional server...",
    selectPackage: "Select Recharge Package",
    bonusText: "Bonus",
    priceLabel: "Total Price",
    rechargeNow: "Proceed to Recharge",
    checkoutTitle: "Secure Gateway",
    checkoutSub: "Complete your premium top-up transaction",
    confirmDetails: "Confirm Top-Up Details",
    paymentMethodTitle: "Select Payment Method",
    cardNumber: "Card Number",
    cardExpiry: "MM/YY",
    cardCVC: "CVC",
    paypalEmail: "PayPal Email Address",
    cryptoAddress: "USDT TRC-20 Transfer Wallet",
    cryptoNotice: "Transfer precisely the required amount to the wallet below. Coins credit after 1 network validation.",
    localWalletNumber: "Mobile Wallet Number",
    localWalletNotice: "Enter your registered wallet number. A validation OTP will be prompted on your phone.",
    processPayment: "Confirm & Pay Now",
    processingText: "Processing transaction...",
    verifyNickname: "Verifying Account...",
    verifyingID: "Checking server for ID validity...",
    idVerified: "Account Verified:",
    idNotFound: "Account ID verified (Simulated)",
    successTitle: "Charge Successful!",
    successSub: "Your account has been credited instantly.",
    transactionID: "Transaction ID",
    targetDetails: "Account Target",
    packageDetails: "Recharge Tier",
    deliveredTo: "Delivered To",
    googlePlayCode: "Digital Gift Code",
    copyCode: "Copy Code",
    codeCopied: "Copied!",
    closeReceipt: "Return to Home",
    orderHistoryTitle: "Your Recharge Activity",
    noOrders: "No previous recharges found.",
    statusCompleted: "Completed",
    statusPending: "Processing",
    statusFailed: "Failed",
    dateLabel: "Date & Time",
    supportTitle: "Live Recharge Support Assistant",
    supportHelp: "Ask anything about card activation, pending payments, or finding game IDs.",
    needHelp: "Need Help?",
    viewHistory: "My Orders",
    home: "Top Up",
    currencySymbol: "$",
    searchHistoryPlaceholder: "Search orders by player ID or email...",
    totalPaid: "Paid Total"
  },
  ar: {
    appName: "GamerCharge",
    subtitle: "المركز الممتاز لشحن الألعاب والبطاقات",
    tagline: "شحن فوري، آمن، وتلقائي بالكامل لألعابك المفضلة.",
    selectGame: "اختر اللعبة أو البطاقة",
    freefireTitle: "جواهر فري فاير",
    pubgTitle: "شدات ببجي موبايل",
    googlePlayTitle: "بطاقات جوجل بلاي",
    freefireDesc: "شحن مباشر إلى معرف اللاعب الخاص بك (Player ID). تسليم فوري داخل اللعبة.",
    pubgDesc: "شحن فوري لـ UC لحساب ببجي. معتمد ورسمي 100%.",
    googlePlayDesc: "أكواد بطاقات رقمية. تسليم فوري على الشاشة وعبر البريد الإلكتروني.",
    playerIDLabel: "معرف لاعب فري فاير (ID)",
    playerIDPlaceholder: "أدخل معرف اللاعب الرقمي (مثال: 482910482)",
    characterIDLabel: "معرف شخصية ببجي (ID)",
    characterIDPlaceholder: "أدخل معرف الشخصية الرقمي (مثال: 51928374)",
    emailLabel: "البريد الإلكتروني للتسليم",
    emailPlaceholder: "أدخل البريد الإلكتروني لاستلام الكود (مثال: alex@gmail.com)",
    regionLabel: "سيرفر اللعبة / المنطقة",
    selectRegion: "اختر السيرفر الإقليمي...",
    selectPackage: "اختر باقة الشحن المناسبة",
    bonusText: "هدية إضافية",
    priceLabel: "السعر الإجمالي",
    rechargeNow: "المتابعة لإتمام الشحن",
    checkoutTitle: "بوابة الدفع الآمنة",
    checkoutSub: "أكمل عملية الشحن الممتازة بأمان",
    confirmDetails: "تأكيد تفاصيل الشحن",
    paymentMethodTitle: "اختر طريقة الدفع",
    cardNumber: "رقم البطاقة الائتمانية",
    cardExpiry: "الشهر / السنة",
    cardCVC: "الرمز السري (CVC)",
    paypalEmail: "البريد الإلكتروني لـ PayPal",
    cryptoAddress: "محفظة تحويل USDT TRC-20",
    cryptoNotice: "قم بتحويل المبلغ المطلوب بدقة إلى المحفظة أدناه. سيتم الشحن بعد تأكيد الشبكة.",
    localWalletNumber: "رقم المحفظة الإلكترونية",
    localWalletNotice: "أدخل رقم المحفظة الإلكترونية المسجل. سيصلك رمز التحقق على هاتفك المحمول.",
    processPayment: "تأكيد ودفع الآن",
    processingText: "جاري معالجة العملية...",
    verifyNickname: "التحقق من الحساب...",
    verifyingID: "جاري التحقق من صحة المعرّف في السيرفر...",
    idVerified: "تم التحقق من الحساب:",
    idNotFound: "تم التحقق من الحساب بنجاح",
    successTitle: "تم الشحن بنجاح!",
    successSub: "تم شحن رصيد حسابك على الفور وبشكل آمن.",
    transactionID: "رقم المعاملة",
    targetDetails: "معرف الحساب المستهدف",
    packageDetails: "باقة الشحن",
    deliveredTo: "تم التسليم إلى",
    googlePlayCode: "كود البطاقة الرقمي",
    copyCode: "نسخ الكود",
    codeCopied: "تم النسخ!",
    closeReceipt: "العودة للرئيسية",
    orderHistoryTitle: "سجل عمليات الشحن الخاصة بك",
    noOrders: "لا يوجد عمليات شحن سابقة.",
    statusCompleted: "مكتمل",
    statusPending: "قيد المعالجة",
    statusFailed: "فشلت",
    dateLabel: "التاريخ والوقت",
    supportTitle: "مساعد الدعم الفني المباشر للشحن",
    supportHelp: "اسأل عن كيفية العثور على المعرف، أو متابعة المدفوعات المعلقة، أو تنشيط الأكواد.",
    needHelp: "هل تحتاج مساعدة؟",
    viewHistory: "طلباتي",
    home: "الشحن المباشر",
    currencySymbol: "$",
    searchHistoryPlaceholder: "ابحث عن العمليات باستخدام المعرف أو البريد الإلكتروني...",
    totalPaid: "المبلغ الإجمالي المدفوع"
  }
};
