import { RechargePackage, PaymentMethod, GameType } from './types';

export const regions = [
  'Middle East & North Africa (MENA)',
  'Global / Europe',
  'North America (NA)',
  'South America (LATAM)',
  'Southeast Asia (SEA)',
  'South Asia (India/Bangladesh)'
];

export const freefirePackages: RechargePackage[] = [
  { id: 'ff_100', game: 'freefire', title: '100 + 10 Diamonds', amount: 100, bonus: 10, price: 0.99, badge: 'Standard' },
  { id: 'ff_310', game: 'freefire', title: '310 + 35 Diamonds', amount: 310, bonus: 35, price: 2.99, badge: 'Popular' },
  { id: 'ff_520', game: 'freefire', title: '520 + 60 Diamonds', amount: 520, bonus: 60, price: 4.99, badge: 'Best Seller' },
  { id: 'ff_1060', game: 'freefire', title: '1060 + 150 Diamonds', amount: 1060, bonus: 150, price: 9.99, badge: 'Double Bonus' },
  { id: 'ff_2180', game: 'freefire', title: '2180 + 350 Diamonds', amount: 2180, bonus: 350, price: 19.99, badge: 'Pro Value' },
  { id: 'ff_5600', game: 'freefire', title: '5600 + 1000 Diamonds', amount: 5600, bonus: 1000, price: 49.99, badge: 'Elite Choice' },
];

export const pubgPackages: RechargePackage[] = [
  { id: 'pubg_60', game: 'pubg', title: '60 UC (Unknown Cash)', amount: 60, price: 0.99, badge: 'Starter' },
  { id: 'pubg_325', game: 'pubg', title: '300 + 25 UC', amount: 300, bonus: 25, price: 4.99, badge: 'Popular' },
  { id: 'pubg_660', game: 'pubg', title: '600 + 60 UC', amount: 600, bonus: 60, price: 9.99, badge: 'Best Seller' },
  { id: 'pubg_1800', game: 'pubg', title: '1500 + 300 UC', amount: 1500, bonus: 300, price: 24.99, badge: 'Recommended' },
  { id: 'pubg_3850', game: 'pubg', title: '3000 + 850 UC', amount: 3000, bonus: 850, price: 49.99, badge: 'Super Value' },
  { id: 'pubg_8100', game: 'pubg', title: '6000 + 2100 UC', amount: 6000, bonus: 2100, price: 99.99, badge: 'Legendary' },
];

export const googlePlayPackages: RechargePackage[] = [
  { id: 'gp_5', game: 'googleplay', title: '$5 Google Play Gift Card', amount: 5, price: 5.00, badge: 'Instant Code' },
  { id: 'gp_10', game: 'googleplay', title: '$10 Google Play Gift Card', amount: 10, price: 10.00, badge: 'Hot Seller' },
  { id: 'gp_25', game: 'googleplay', title: '$25 Google Play Gift Card', amount: 25, price: 24.50, badge: '2% Discount' },
  { id: 'gp_50', game: 'googleplay', title: '$50 Google Play Gift Card', amount: 50, price: 48.00, badge: '4% Discount' },
  { id: 'gp_100', game: 'googleplay', title: '$100 Google Play Gift Card', amount: 100, price: 95.00, badge: '5% Discount' },
];

export const paymentMethods: PaymentMethod[] = [
  {
    id: 'card',
    nameEn: 'Credit / Debit Card',
    nameAr: 'بطاقة ائتمان / خصم',
    icon: 'CreditCard',
    descriptionEn: 'Visa, MasterCard, or American Express. Processed instantly.',
    descriptionAr: 'فيزا، ماستركارد، أو أمريكان إكسبريس. شحن فوري وآمن.'
  },
  {
    id: 'paypal',
    nameEn: 'PayPal Gateway',
    nameAr: 'حساب بايبال',
    icon: 'Wallet',
    descriptionEn: 'Check out swiftly with your secure PayPal account.',
    descriptionAr: 'الدفع الآمن والسريع من خلال رصيد حساب PayPal الخاص بك.'
  },
  {
    id: 'local_wallet',
    nameEn: 'Local Mobile Wallet',
    nameAr: 'محفظة إلكترونية محلية',
    icon: 'PhoneCall',
    descriptionEn: 'Vodafone Cash, InstaPay, Orange Money, or local carrier bill.',
    descriptionAr: 'فودافون كاش، إنستاباي، أورنج ماني، أو رصيد الخط.'
  },
  {
    id: 'crypto',
    nameEn: 'Tether (USDT TRC-20)',
    nameAr: 'العملات الرقمية (USDT)',
    icon: 'Coins',
    descriptionEn: 'Crypto payments processed in 2 minutes. Best for anonymity.',
    descriptionAr: 'الدفع بالعملات المشفرة مع تأكيد فوري عبر شبكة TRC-20.'
  }
];

// Helper to generate a consistent, premium looking username based on numeric ID
export function getNicknameForId(game: GameType, id: string): string {
  if (!id || id.trim().length === 0) return '';
  
  const trimmed = id.trim();
  const sum = trimmed.split('').reduce((acc, char) => acc + (char.charCodeAt(0) || 0), 0);
  
  const prefixes = [
    'Elite', 'Viper', 'Ghost', 'NoobMaster', 'Alpha', 'ProGamer', 'Shadow', 'Phoenix', 
    'Raptor', 'Sniper', 'Tornado', 'Slayer', 'Zeus', 'Major', 'DesertFox', 'Knight'
  ];
  
  const suffixes = [
    'YT', '99', 'OP', 'King', 'X', 'Chief', 'Warrior', 'Pro', 'Boss', 'Gamer', 'FF', 'PUBG',
    '300', 'Lord', 'Assassin', 'Strike'
  ];
  
  const prefix = prefixes[sum % prefixes.length];
  const suffix = suffixes[(sum * 7) % suffixes.length];
  
  if (game === 'freefire') {
    return `FF_${prefix}${suffix}`;
  } else if (game === 'pubg') {
    return `${prefix}_${suffix}_PUBG`;
  }
  
  return `${prefix}_Gamer`;
}

// Generate random mock code for Google Play card code delivery
export function generateGooglePlayCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const segment = () => Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  return `GPLAY-${segment()}-${segment()}-${segment()}-${segment()}`;
}

// Generate random transaction ID
export function generateTxnId(): string {
  return `TXN-${Math.floor(100000 + Math.random() * 900000)}`;
}

// List of interesting support/chatbot FAQ interactions for simulated chat
export interface SupportFAQ {
  keywords: string[];
  replyEn: string;
  replyAr: string;
}

export const supportFAQs: SupportFAQ[] = [
  {
    keywords: ['id', 'find', 'location', 'معرف', 'اين', 'كيف'],
    replyEn: "To find your Free Fire ID, tap your profile avatar in the top-left corner. Your UID is listed under your nickname. For PUBG Mobile, open the game lobby, tap your avatar, and copy the numeric Character ID near the top.",
    replyAr: "للعثور على معرّف فري فاير الخاص بك، اضغط على صورتك الشخصية أعلى يسار الشاشة. ستجد الـ ID الخاص بك أسفل اسمك. بالنسبة لـ ببجي، افتح القائمة الرئيسية للعبة، اضغط على صورتك الشخصية وانسخ الرقم التعريفي (Character ID) الموجود في الأعلى."
  },
  {
    keywords: ['pending', 'delay', 'time', 'تاخير', 'معلق', 'وقت', 'متى'],
    replyEn: "Most recharges are completed within 3 to 10 seconds. In rare cases during server updates, it may take up to 10 minutes. If you experience any delays, please keep your Transaction ID handy.",
    replyAr: "تكتمل معظم عمليات الشحن وتصل لحسابك خلال 3 إلى 10 ثوانٍ فقط. في حالات نادرة أثناء تحديثات اللعبة، قد تستغرق حتى 10 دقائق. إذا واجهت أي تأخير، يرجى تزويدنا برقم المعاملة (ID)."
  },
  {
    keywords: ['refund', 'cancel', 'استرجاع', 'الغاء', 'غلط'],
    replyEn: "Because top-ups are processed instantly and directly to the game server, we cannot undo or refund transactions after they are sent. Please carefully double-check your Player ID before submitting payment.",
    replyAr: "نظراً لأن عمليات شحن الألعاب تتم تلقائياً وفورياً إلى سيرفرات اللعبة مباشرةً، فلا يمكننا إلغاء المعاملة أو إرجاع المبلغ بعد اكتمال الدفع. يرجى التأكد جيداً من المعرف (ID) الخاص بك قبل تأكيد الطلب."
  },
  {
    keywords: ['payment', 'method', 'cash', 'طريقة', 'دفع', 'كاش'],
    replyEn: "We support Visa/MasterCard, PayPal, secure USDT Transfer, and local mobile payment networks (like Vodafone Cash, Orange Money, InstaPay, Fawry). Select your preferred gateway on the checkout screen.",
    replyAr: "نحن ندعم البطاقات الائتمانية، بايبال، التحويل المشفر الآمن USDT، والمحافظ الإلكترونية المحلية (مثل فودافون كاش، InstaPay، أورنج ماني، فوري). اختر طريقتك المفضلة عند الدفع."
  }
];
